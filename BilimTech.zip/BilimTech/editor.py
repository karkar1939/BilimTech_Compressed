"""Teacher-owned question bank editor; no code changes needed to extend the bank."""
import tkinter as tk
from tkinter import ttk, messagebox
from ui import Button, BG, ScrollPage

STRINGS={
'ru':['Банк заданий','Добавить вопрос','Изменить','Включить / выключить','Закрыть','Тема','Режим','Диагностика','Тренировка','Источник','Состояние','Активно','Выключено','Учитель','Встроенное','Новая тема','Название темы','Вопрос','Объяснение','Варианты ответа (общие для трёх языков)','Правильный вариант','Сохранить','Отмена','Выбери вопрос учителя. Встроенные вопросы доступны только для просмотра.','Заполни вопрос и объяснение хотя бы на текущем языке. Пустые переводы будут заменены этим текстом.','Все четыре варианта должны быть заполнены и отличаться.','Не удалось сохранить','Для каждого режима выбирается случайная выборка активных вопросов по темам.','Добавить тему','Название на текущем языке обязательно; пустые переводы будут заменены им.','Выбери существующую тему.'],
'ky':['Тапшырмалар банкы','Суроо кошуу','Өзгөртүү','Иштетүү / өчүрүү','Жабуу','Тема','Режим','Диагностика','Машыгуу','Булак','Абалы','Активдүү','Өчүрүлгөн','Мугалим','Камтылган','Жаңы тема','Теманын аталышы','Суроо','Түшүндүрмө','Жооптор (үч тил үчүн жалпы)','Туура жооп','Сактоо','Жокко чыгаруу','Мугалимдин суроосун танда. Камтылган суроолор өзгөртүлбөйт.','Учурдагы тилде суроону жана түшүндүрмөнү толтур. Бош котормолор ушул текст менен толтурулат.','Төрт жоопту толтур; алар ар башка болушу керек.','Сактоо мүмкүн болгон жок','Ар бир режимде активдүү суроолор темалар боюнча туш келди тандалат.','Тема кошуу','Учурдагы тилде аталышы керек; бош котормолор ошол аталыш менен толтурулат.','Учурдагы теманы танда.'],
'en':['Question bank','Add question','Edit','Enable / disable','Close','Topic','Mode','Diagnostic','Practice','Source','Status','Active','Disabled','Teacher','Built-in','New topic','Topic name','Question','Explanation','Answer options (shared across three languages)','Correct option','Save','Cancel','Select a teacher question. Built-in questions are read-only.','Enter a question and explanation in the current language. Blank translations will use that text.','All four options must be filled and distinct.','Could not save','Each mode randomly samples active questions for each topic.','Add topic','A name in the current language is required; blank translations use it.','Select an existing topic.']}

class BankEditor(tk.Toplevel):
    def __init__(self,app):
        super().__init__(app); self.app=app; self.store=app.store; self.lang=app.lang; self.s=STRINGS[self.lang]
        self.title('BilimTech • '+self.s[0]); self.geometry(f'{min(1140,self.winfo_screenwidth()-60)}x{min(720,self.winfo_screenheight()-90)}'); self.minsize(800,550)
        self.transient(app); self.grab_set()
        bar=ttk.Frame(self,padding=10); bar.pack(fill='x')
        for idx,command in [(1,lambda:self.form()),(2,self.edit),(3,self.toggle),(28,self.topic_form)]:
            Button(bar,text=self.s[idx],command=command,variant='primary' if idx==1 else 'secondary').pack(side='left',padx=3)
        Button(bar,text=self.s[4],command=self.close,variant='secondary').pack(side='right')
        ttk.Label(self,text=self.s[27],wraplength=900).pack(anchor='w',padx=12,pady=8)
        frame=ttk.Frame(self,padding=10); frame.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(frame,columns=('topic','mode','text','source','status'),show='headings',selectmode='browse')
        for key,title,width in [('topic',self.s[5],145),('mode',self.s[6],110),('text',self.s[17],350),('source',self.s[9],100),('status',self.s[10],100)]:
            self.tree.heading(key,text=title); self.tree.column(key,width=width)
        scroll=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview); self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side='left',fill='both',expand=True); scroll.pack(side='right',fill='y')
        self.tree.bind('<Double-1>',lambda e:self.edit()); self.protocol('WM_DELETE_WINDOW',self.close); self.refresh()
    def refresh(self):
        self.topics=self.store.topics(); self.bank={str(q['id']):q for q in self.store.bank(True)}
        self.tree.delete(*self.tree.get_children())
        for key,q in self.bank.items():
            self.tree.insert('','end',iid=key,values=(self.topics[q['topic']][self.lang],self.s[8 if q['practice'] else 7],q['text'][self.lang],self.s[13 if q['custom'] else 14],self.s[11 if q['active'] else 12]))
    def selected(self):
        selection=self.tree.selection()
        q=self.bank.get(selection[0]) if selection else None
        if not q or not q['custom']: messagebox.showinfo(self.s[0],self.s[23],parent=self); return None
        return q
    def edit(self):
        q=self.selected()
        if q: self.form(q)
    def toggle(self):
        q=self.selected()
        if q:
            try: self.store.set_active(q['id'],not q['active']); self.refresh()
            except Exception as exc: messagebox.showerror(self.s[26],str(exc),parent=self)
    def close(self):
        self.app.topics=self.store.topics(); callback=getattr(self,'on_close',self.app.home); self.destroy(); callback()
    def topic_form(self):
        dialog=tk.Toplevel(self); dialog.title(self.s[15]); dialog.transient(self); dialog.grab_set()
        entries={}
        for lang,label in [('ru','Русский'),('ky','Кыргызча'),('en','English')]:
            ttk.Label(dialog,text=f'{self.s[16]} • {label}').pack(anchor='w',padx=15,pady=(10,0))
            var=tk.StringVar(); entries[lang]=var; ttk.Entry(dialog,textvariable=var,width=45).pack(padx=15)
        ttk.Label(dialog,text=self.s[29],wraplength=450).pack(padx=15,pady=10)
        def save():
            fallback=entries[self.lang].get().strip()
            if not fallback: messagebox.showwarning(self.s[15],self.s[29],parent=dialog); return
            try: self.store.add_topic({lang:var.get().strip() or fallback for lang,var in entries.items()})
            except Exception as exc: messagebox.showerror(self.s[26],str(exc),parent=dialog); return
            dialog.destroy(); self.grab_set(); self.refresh()
        Button(dialog,text=self.s[21],command=save).pack(pady=10)
    def form(self,q=None):
        dialog=tk.Toplevel(self); dialog.title(self.s[2 if q else 1]); dialog.geometry(f'{min(840,self.winfo_screenwidth()-60)}x{min(830,self.winfo_screenheight()-90)}'); dialog.minsize(700,560); dialog.transient(self); dialog.grab_set()
        scroller=ScrollPage(dialog); scroller.pack(fill='both',expand=True); body=scroller.content
        labels={}
        for key,value in self.topics.items():
            label=value[self.lang]
            labels[key]=label if label not in labels.values() else f'{label} ({len(labels)+1})'
        selected_topic=tk.StringVar(value=labels[q['topic']] if q else next(iter(labels.values())))
        ttk.Label(body,text=self.s[5]).pack(anchor='w')
        ttk.Combobox(body,values=list(labels.values()),textvariable=selected_topic,state='readonly',width=65).pack(fill='x')
        mode=tk.StringVar(value=self.s[8 if q and q['practice'] else 7])
        ttk.Combobox(body,values=[self.s[7],self.s[8]],textvariable=mode,state='readonly').pack(anchor='w',pady=10)
        ttk.Label(body,text=self.s[24],wraplength=720).pack(anchor='w',pady=5)
        tabs=ttk.Notebook(body); tabs.pack(fill='both',expand=True,pady=6); fields={}
        languages=[('ru','Русский'),('ky','Кыргызча'),('en','English')]
        for lang,label in languages:
            page=ttk.Frame(tabs,padding=8); tabs.add(page,text=label); fields[lang]={}
            for field,idx in [('text',17),('explanation',18)]:
                ttk.Label(page,text=self.s[idx]).pack(anchor='w')
                widget=tk.Text(page,height=3,wrap='word',font=('Roboto Condensed',11)); widget.pack(fill='both',expand=True,pady=4)
                if q: widget.insert('1.0',q[field][lang])
                fields[lang][field]=widget
        tabs.select([lang for lang,label in languages].index(self.lang))
        ttk.Label(body,text=self.s[19]).pack(anchor='w',pady=(8,2))
        options=[]; correct=tk.IntVar(value=q['answer'] if q else 0)
        for i in range(4):
            row=ttk.Frame(body); row.pack(fill='x',pady=2)
            ttk.Radiobutton(row,text=str(i+1),variable=correct,value=i).pack(side='left')
            var=tk.StringVar(value=q['options'][i] if q else ''); options.append(var)
            ttk.Entry(row,textvariable=var).pack(side='left',fill='x',expand=True)
        ttk.Label(body,text=self.s[20]+': ◉ 1 / 2 / 3 / 4').pack(anchor='w',pady=4)
        def save():
            payload={'text':{},'explanation':{},'options':[v.get().strip() for v in options],'answer':correct.get(),'practice':mode.get()==self.s[8]}
            payload['topic']=next((key for key,value in labels.items() if value==selected_topic.get()),None)
            if payload['topic'] is None: messagebox.showwarning(self.s[0],self.s[30],parent=dialog); return
            for field in ('text','explanation'):
                fallback=fields[self.lang][field].get('1.0','end').strip()
                if not fallback: messagebox.showwarning(self.s[0],self.s[24],parent=dialog); return
                payload[field]={lang:fields[lang][field].get('1.0','end').strip() or fallback for lang,_ in languages}
            if any(not value for value in payload['options']) or len({v.casefold() for v in payload['options']})!=4:
                messagebox.showwarning(self.s[0],self.s[25],parent=dialog); return
            try: self.store.put_question(payload,q['id'] if q else None)
            except Exception as exc: messagebox.showerror(self.s[26],str(exc),parent=dialog); return
            dialog.destroy(); self.grab_set(); self.refresh()
        buttons=ttk.Frame(body); buttons.pack(fill='x',pady=8)
        Button(buttons,text=self.s[21],command=save).pack(side='left')
        Button(buttons,text=self.s[22],variant='secondary',command=lambda:(dialog.destroy(),self.grab_set())).pack(side='right')
        scroller.activate()
