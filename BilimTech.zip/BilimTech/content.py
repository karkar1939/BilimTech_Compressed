"""Trilingual mathematics bank. Correct answer is an option index."""
LANGS = {'Русский':'ru', 'Кыргызча':'ky', 'English':'en'}
TEXT = {
'ru': ['Ученик','Учитель','Имя или код ученика','Класс','Начать тест','Ответить','Далее','Результат','Тема','Освоение, %','Дополнительные задания','Обновить','Экспорт CSV','Демонстрационные данные','Все классы','Выбери ответ','Заполни имя и класс','Математика • базовый уровень','Верно!','Неверно.','Правильный ответ','Пояснение','Завершить','Нет результатов','Диагностика','Тренировка','Попытки','Ученики','Средний результат','Сначала повтори темы с результатом ниже 70%.','Тест не выявил слабых тем. Можно закрепить материал.','Результаты сохранены','Данные демонстрационные: класс ДЕМО','Дата','Режим'],
'ky': ['Окуучу','Мугалим','Окуучунун аты же коду','Класс','Тестти баштоо','Жооп берүү','Кийинки','Жыйынтык','Тема','Өздөштүрүү, %','Кошумча тапшырмалар','Жаңыртуу','CSV экспорттоо','Көрсөтмө маалыматтар','Бардык класстар','Жоопту танда','Атыңды жана классты жаз','Математика • негизги деңгээл','Туура!','Туура эмес.','Туура жооп','Түшүндүрмө','Бүтүрүү','Жыйынтыктар жок','Диагностика','Машыгуу','Аракеттер','Окуучулар','Орточо жыйынтык','70%дан төмөн темаларды кайтала.','Алсыз темалар табылган жок. Билимди бекемдесе болот.','Жыйынтыктар сакталды','Көрсөтмө маалыматтар: ДЕМО классы','Күнү','Режим'],
'en': ['Student','Teacher','Student name or code','Class','Start test','Submit','Next','Result','Topic','Mastery, %','Practice tasks','Refresh','Export CSV','Demo data','All classes','Choose an answer','Enter name and class','Mathematics • foundation level','Correct!','Incorrect.','Correct answer','Explanation','Finish','No results','Diagnostic','Practice','Attempts','Students','Average score','Review topics below 70%.','No weak topics found. You can practise to consolidate.','Results saved','Demo data: class ДЕМО','Date','Mode']}
TOPICS = {'fractions':{'ru':'Дроби','ky':'Бөлчөктөр','en':'Fractions'},'percent':{'ru':'Проценты','ky':'Пайыздар','en':'Percentages'},'equations':{'ru':'Уравнения','ky':'Теңдемелер','en':'Equations'}}
QUESTIONS=[]
def add(topic, expression, options, answer, explanation, practice=False):
    QUESTIONS.append(dict(id=len(QUESTIONS)+1,topic=topic,text={k:expression for k in LANGS.values()},options=options,answer=answer,explanation=dict(zip(('ru','ky','en'),explanation)),practice=practice))
for expr,opts,ans,exp in [
('1/2 + 1/4 = ?', ['1/6','3/4','2/4','1'],1,('Приведи к знаменателю 4: 2/4 + 1/4 = 3/4.','Бөлүмүн 4 кыл: 2/4 + 1/4 = 3/4.','Use denominator 4: 2/4 + 1/4 = 3/4.')),
('3/4 − 1/4 = ?', ['1/4','1','1/2','3/8'],2,('2/4 сокращается до 1/2.','2/4 = 1/2 болуп кыскарат.','Simplify 2/4 to 1/2.')),
('2/3 × 3/4 = ?', ['1/2','5/7','2/7','3/2'],0,('Умножь числители и знаменатели: 6/12 = 1/2.','Алымдарды жана бөлүмдөрдү көбөйт: 6/12 = 1/2.','Multiply numerators and denominators: 6/12 = 1/2.'))]: add('fractions',expr,opts,ans,exp)
for n,p in [(200,10),(80,25),(50,20)]:
    val=n*p//100
    add('percent',f'{p}% × {n} = ?',list(map(str,[val,n+p,p,n])),0,(f'{n} × {p} / 100 = {val}.',)*3)
for a,b in [(5,12),(3,10),(8,20)]:
    x=b-a
    add('equations',f'x + {a} = {b}; x = ?',list(map(str,[a+b,x,a,b])),1,(f'x = {b} − {a} = {x}.',)*3)
for a,b in [(1,5),(2,7),(3,8)]:
    add('fractions',f'{a}/{b} + 1/{b} = ?',[f'{a+1}/{b}',f'{a+1}/{2*b}',f'{a}/{b+1}','0'],0,('При одинаковых знаменателях складываются числители.','Бөлүмдөр бирдей болсо, алымдар кошулат.','With equal denominators, add the numerators.'),True)
for n,p in [(300,10),(60,50),(120,25)]:
    v=n*p//100
    add('percent',f'{p}% × {n} = ?',list(map(str,[n,p,v,n+p])),2,(f'{n} × {p} / 100 = {v}.',)*3,True)
for a,b in [(2,6),(3,12),(5,20)]:
    add('equations',f'{a}x = {b}; x = ?',list(map(str,[b-a,b+a,b*a,b//a])),3,(f'x = {b} / {a} = {b//a}.',)*3,True)

# Additional distinct foundation exercises, with worked explanations.
for practice in (False, True):
    for denominator in range(5, 15):
        a = 1 if not practice else 2
        b = 2 if not practice else 3
        correct = f'{a+b}/{denominator}'
        exp = (
            f'Общий знаменатель остаётся {denominator}. Складываем числители: {a} + {b} = {a+b}. Ответ: {correct}.',
            f'Жалпы бөлүм {denominator} бойдон калат. Алымдарды кошобуз: {a} + {b} = {a+b}. Жооп: {correct}.',
            f'Keep the common denominator {denominator}. Add the numerators: {a} + {b} = {a+b}. Answer: {correct}.')
        add('fractions',f'{a}/{denominator} + {b}/{denominator} = ?',
            [correct,f'{a+b}/{2*denominator}',f'{a*b}/{denominator}',f'{a+b+2}/{denominator}'],0,exp,practice)
    for n in range(400 if not practice else 660, 600 if not practice else 860, 20):
        p = 25 if not practice else 15
        v = n*p//100
        exp=(f'Чтобы найти {p}% от {n}, умножь {n} на {p} и раздели на 100: {v}.',
             f'{n} санынын {p}%ын табуу үчүн {n} санын {p} санына көбөйтүп, 100гө бөл: {v}.',
             f'To find {p}% of {n}, multiply {n} by {p} and divide by 100: {v}.')
        add('percent',f'{p}% × {n} = ?',[str(v),str(v+5),str(n+p),str(v+10)],0,exp,practice)
    for a in range(4 if not practice else 14, 14 if not practice else 24):
        x=a+3; b=a+x
        exp=(f'Вычти {a} из обеих частей: x = {b} − {a} = {x}.',
             f'Эки жагынан тең {a} санын кемит: x = {b} − {a} = {x}.',
             f'Subtract {a} from both sides: x = {b} − {a} = {x}.')
        add('equations',f'x + {a} = {b}; x = ?',list(map(str,[x,b+a,a,b])),0,exp,practice)

TOPICS.update({
    'geometry': {'ru':'Геометрия','ky':'Геометрия','en':'Geometry'},
    'arithmetic': {'ru':'Порядок действий','ky':'Амалдардын тартиби','en':'Order of operations'},
})

def add_varied(topic, text, value, distractors, explanations, practice):
    """Rotate correct-option positions and reject duplicate options."""
    options = [str(value)] + [str(v) for v in distractors]
    assert len(set(options)) == 4
    shift = len(QUESTIONS) % 4
    options = options[-shift:] + options[:-shift] if shift else options
    add(topic, text, options, shift, explanations, practice)

for practice in (False, True):
    for i in range(10):
        d = 17 + i + (20 if practice else 0)
        a = d - 3
        value = f'{a-2}/{d}'
        add_varied('fractions',f'{a}/{d} − 2/{d} = ?',value,
            [f'{a+2}/{d}',f'{a-2}/{d+2}',f'{a-1}/{d}'],
            (f'Знаменатель остаётся {d}. Вычти числители: {a} − 2 = {a-2}.',
             f'Бөлүм {d} бойдон калат. Алымдарды кемит: {a} − 2 = {a-2}.',
             f'Keep denominator {d}. Subtract numerators: {a} − 2 = {a-2}.'),practice)
        n = 140 + i*20 + (300 if practice else 0)
        value = n//2
        add_varied('percent',f'50% × {n} = ?',value,[value+10,n+50,n-10],
            (f'50% — половина числа: {n} / 2 = {value}.',
             f'50% — сандын жарымы: {n} / 2 = {value}.',
             f'50% means half: {n} / 2 = {value}.'),practice)
        a = 4+i; x = 6+i+(10 if practice else 0); b = a*x
        add_varied('equations',f'{a}x = {b}; x = ?',x,[x+1,b+a,b-a],
            (f'Раздели обе части на {a}: x = {b} / {a} = {x}.',
             f'Эки жагын тең {a} санына бөл: x = {b} / {a} = {x}.',
             f'Divide both sides by {a}: x = {b} / {a} = {x}.'),practice)
    for i in range(15):
        a=3+i+(20 if practice else 0); b=7+i
        p=2*(a+b)
        add_varied('geometry','',p,[a+b,a+b+1,p+2],
            (f'Периметр прямоугольника: P = 2 × (a + b) = 2 × ({a} + {b}) = {p} см.',
             f'Тик бурчтуктун периметри: P = 2 × (a + b) = 2 × ({a} + {b}) = {p} см.',
             f'Rectangle perimeter: P = 2 × (a + b) = 2 × ({a} + {b}) = {p} cm.'),practice)
        QUESTIONS[-1]['text']={
            'ru':f'Стороны прямоугольника: {a} см и {b} см. Чему равен периметр (см)?',
            'ky':f'Тик бурчтуктун жактары: {a} см жана {b} см. Периметри канча (см)?',
            'en':f'A rectangle has sides {a} cm and {b} cm. Find its perimeter (cm).'}
        c=2+i; d=4+i; e=3+(2 if practice else 0)
        value=c+d*e
        add_varied('arithmetic',f'{c} + {d} × {e} = ?',value,[(c+d)*e,value+1,value-1],
            (f'Сначала умножение: {d} × {e} = {d*e}. Затем сложение: {c} + {d*e} = {value}.',
             f'Адегенде көбөйтүү: {d} × {e} = {d*e}. Андан кийин кошуу: {c} + {d*e} = {value}.',
             f'Multiply first: {d} × {e} = {d*e}. Then add: {c} + {d*e} = {value}.'),practice)
