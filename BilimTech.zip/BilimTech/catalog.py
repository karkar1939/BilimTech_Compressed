"""Subject catalog and foundation science exercises; all labels have three languages."""
from content import QUESTIONS, TOPICS

def tr(ru,ky,en):return dict(zip(('ru','ky','en'),(ru,ky,en)))
SUBJECTS={
'math':tr('Математика','Математика','Mathematics'),
'physics':tr('Физика','Физика','Physics'),
'chemistry':tr('Химия','Химия','Chemistry'),
'geography':tr('География','География','Geography'),
'geometry':tr('Геометрия','Геометрия','Geometry'),
'other':tr('Дополнительные темы','Кошумча темалар','Additional topics')}
TOPICS.update({k:v for k,v in SUBJECTS.items() if k in ('physics','chemistry','geography')})

def subject_for(topic):
    if topic in ('fractions','percent','equations','arithmetic'):return 'math'
    return topic if topic in SUBJECTS else 'other'

SCIENCE=[]
def science(topic,text,options,answer,explanation,practice=False):
    SCIENCE.append(dict(id=200000+len(SCIENCE),topic=topic,text=text,options=options,answer=answer,explanation=explanation,practice=practice))
for practice in (False,True):
    for i in range(3):
        t=2+i; v=6+i+(4 if practice else 0); d=t*v
        science('physics',tr(f'Тело прошло {d} м за {t} с. Найди скорость (м/с).',f'Дене {t} секундада {d} м жүрдү. Ылдамдыгын тап (м/с).',f'An object moves {d} m in {t} s. Find its speed (m/s).'),list(map(str,[v,d+t,d-t,v+2])),0,tr(f'v = s / t = {d} / {t} = {v} м/с.',f'v = s / t = {d} / {t} = {v} м/с.',f'v = s / t = {d} / {t} = {v} m/s.'),practice)
        m=3+i; a=2+i+(3 if practice else 0); f=m*a
        science('physics',tr(f'Масса {m} кг, ускорение {a} м/с². Чему равна сила (Н)?',f'Масса {m} кг, ылдамдануу {a} м/с². Күч канча (Н)?',f'Mass is {m} kg and acceleration is {a} m/s². Find the force (N).'),list(map(str,[f+1,f,f+3,f+5])),1,tr(f'Второй закон Ньютона: F = ma = {m} × {a} = {f} Н.',f'Ньютондун экинчи закону: F = ma = {m} × {a} = {f} Н.',f"Newton's second law: F = ma = {m} × {a} = {f} N."),practice)

chem=[
(tr('Какова формула воды?','Суунун формуласы кандай?','What is the formula of water?'),['H₂O','CO₂','O₂','NaCl'],0,tr('Вода содержит два атома водорода и один атом кислорода.','Суу эки суутек жана бир кычкылтек атомунан турат.','Water contains two hydrogen atoms and one oxygen atom.')),
(tr('Как обозначается кислород?','Кычкылтектин белгиси кандай?','What is the symbol for oxygen?'),['H','N','O','C'],2,tr('O — химический символ кислорода.','O — кычкылтектин химиялык белгиси.','O is the chemical symbol for oxygen.')),
(tr('Какая частица имеет отрицательный заряд?','Кайсы бөлүкчө терс зарядга ээ?','Which particle has a negative charge?'),['Протон / Proton','Электрон / Electron','Нейтрон / Neutron','Фотон / Photon'],1,tr('Электрон имеет отрицательный электрический заряд.','Электрон терс электр зарядына ээ.','An electron has a negative electric charge.')),
(tr('Сколько атомов в молекуле CO₂?','CO₂ молекуласында канча атом бар?','How many atoms are in one CO₂ molecule?'),['1','2','3','4'],2,tr('Один атом углерода и два атома кислорода: всего 3.','Бир көмүртек жана эки кычкылтек атому: бардыгы 3.','One carbon atom and two oxygen atoms: 3 in total.')),
(tr('Каков pH нейтральной воды при 25 °C?','25 °Cде нейтралдуу суунун pH мааниси канча?','What is the pH of neutral water at 25 °C?'),['1','5','7','14'],2,tr('При 25 °C нейтральный раствор имеет pH 7.','25 °Cде нейтралдуу эритменин pH мааниси 7.','At 25 °C a neutral solution has pH 7.')),
(tr('Какова формула поваренной соли?','Аш тузунун формуласы кандай?','What is the formula of table salt?'),['NaCl','H₂','CO','NH₃'],0,tr('Поваренная соль — хлорид натрия, NaCl.','Аш тузу — натрий хлориди, NaCl.','Table salt is sodium chloride, NaCl.')),
(tr('Как обозначается водород?','Суутектин белгиси кандай?','What is the symbol for hydrogen?'),['He','H','O','Fe'],1,tr('H — символ водорода.','H — суутектин белгиси.','H is the symbol for hydrogen.')),
(tr('Каков атомный номер углерода?','Көмүртектин атомдук номери канча?','What is the atomic number of carbon?'),['4','6','8','12'],1,tr('У углерода 6 протонов, поэтому его атомный номер 6.','Көмүртекте 6 протон бар, атомдук номери 6.','Carbon has 6 protons, so its atomic number is 6.')),
(tr('Какой заряд у протона?','Протондун заряды кандай?','What is the charge of a proton?'),['−1','0','+1','−2'],2,tr('Протон несёт положительный элементарный заряд.','Протон оң элементардык зарядга ээ.','A proton carries a positive elementary charge.')),
(tr('Сколько атомов водорода в NH₃?','NH₃ ичинде канча суутек атому бар?','How many hydrogen atoms are in NH₃?'),['1','2','3','4'],2,tr('Индекс 3 относится к водороду H.','3 индекси H суутегине тиешелүү.','The subscript 3 belongs to hydrogen, H.')),
(tr('Что происходит с атомами при обычной химической реакции?','Кадимки химиялык реакцияда атомдор эмне болот?','What happens to atoms in an ordinary chemical reaction?'),['Исчезают / Disappear','Перегруппируются / Rearrange','Становятся светом / Become light','Всегда делятся / Always split'],1,tr('Атомы перегруппируются, образуя новые вещества.','Атомдор кайра топтолуп, жаңы заттарды түзөт.','Atoms rearrange to form new substances.')),
(tr('Какой символ у железа?','Темирдин белгиси кандай?','What is the symbol for iron?'),['I','Ir','F','Fe'],3,tr('Fe — символ железа.','Fe — темирдин белгиси.','Fe is the symbol for iron.'))]
geo=[
(tr('Столица Кыргызстана?','Кыргызстандын борбору кайсы?','What is the capital of Kyrgyzstan?'),['Бишкек / Bishkek','Ош / Osh','Нарын / Naryn','Талас / Talas'],0,tr('Столица Кыргызстана — Бишкек.','Кыргызстандын борбору — Бишкек.','Bishkek is the capital of Kyrgyzstan.')),
(tr('В какой части Азии находится Кыргызстан?','Кыргызстан Азиянын кайсы бөлүгүндө?','In which part of Asia is Kyrgyzstan?'),['Восточная / East','Центральная / Central','Южная / South','Западная / West'],1,tr('Кыргызстан расположен в Центральной Азии.','Кыргызстан Борбордук Азияда жайгашкан.','Kyrgyzstan is in Central Asia.')),
(tr('Какой океан самый большой по площади?','Аянты боюнча эң чоң океан кайсы?','Which ocean is largest by area?'),['Тихий / Pacific','Атлантический / Atlantic','Индийский / Indian','Северный Ледовитый / Arctic'],0,tr('Тихий океан имеет наибольшую площадь.','Тынч океандын аянты эң чоң.','The Pacific Ocean has the largest area.')),
(tr('Какой материк находится на Южном полюсе?','Түштүк уюлда кайсы материк жайгашкан?','Which continent contains the South Pole?'),['Африка / Africa','Австралия / Australia','Антарктида / Antarctica','Европа / Europe'],2,tr('Южный полюс расположен в Антарктиде.','Түштүк уюл Антарктидада жайгашкан.','The South Pole is in Antarctica.')),
(tr('Какова широта экватора?','Экватордун кеңдиги канча?','What is the latitude of the equator?'),['0°','45°','90°','180°'],0,tr('Экватор соответствует широте 0°.','Экватор 0° кеңдикке туура келет.','The equator is at latitude 0°.')),
(tr('Какая страна граничит с Кыргызстаном?','Кайсы өлкө Кыргызстан менен чектешет?','Which country borders Kyrgyzstan?'),['Монголия / Mongolia','Казахстан / Kazakhstan','Индия / India','Турция / Türkiye'],1,tr('Кыргызстан граничит с Казахстаном, Узбекистаном, Таджикистаном и Китаем.','Кыргызстан Казакстан, Өзбекстан, Тажикстан жана Кытай менен чектешет.','Kyrgyzstan borders Kazakhstan, Uzbekistan, Tajikistan and China.')),
(tr('Какое крупное озеро находится в Кыргызстане?','Кыргызстанда кайсы чоң көл жайгашкан?','Which large lake is in Kyrgyzstan?'),['Байкал / Baikal','Иссык-Куль / Issyk-Kul','Виктория / Victoria','Титикака / Titicaca'],1,tr('Иссык-Куль находится на северо-востоке Кыргызстана.','Ысык-Көл Кыргызстандын түндүк-чыгышында жайгашкан.','Issyk-Kul is in northeastern Kyrgyzstan.')),
(tr('Масштаб 1:100 000. Сколько км соответствует 1 см на карте?','Масштаб 1:100 000. Картадагы 1 см канча кмге барабар?','At a scale of 1:100,000, how many km does 1 cm represent?'),['0.1','1','10','100'],1,tr('100 000 см = 1 000 м = 1 км.','100 000 см = 1 000 м = 1 км.','100,000 cm = 1,000 m = 1 km.')),
(tr('В каком направлении возрастает широта от экватора к Северному полюсу?','Экватордон Түндүк уюлга карай кеңдик кайсы багытта өсөт?','In which direction does latitude increase from the equator to the North Pole?'),['Север / North','Юг / South','Восток / East','Запад / West'],0,tr('От экватора к Северному полюсу северная широта растёт до 90°.','Экватордон Түндүк уюлга карай түндүк кеңдик 90°га чейин өсөт.','North latitude increases to 90° at the North Pole.')),
(tr('Какая горная система занимает значительную часть Кыргызстана?','Кыргызстандын көп бөлүгүн кайсы тоо системасы ээлейт?','Which mountain system covers a large part of Kyrgyzstan?'),['Альпы / Alps','Анды / Andes','Тянь-Шань / Tian Shan','Атлас / Atlas'],2,tr('Тянь-Шань занимает значительную часть Кыргызстана.','Теңир-Тоо Кыргызстандын көп бөлүгүн ээлейт.','The Tian Shan covers much of Kyrgyzstan.')),
(tr('Что показывает долгота?','Узундук эмнени көрсөтөт?','What does longitude measure?'),['Расстояние к востоку/западу в градусах / East-west angular position','Высоту / Altitude','Температуру / Temperature','Осадки / Rainfall'],0,tr('Долгота — угловое положение к востоку или западу от нулевого меридиана.','Узундук — нөлдүк меридиандан чыгышка же батышка карай бурчтук аралык.','Longitude is angular position east or west of the prime meridian.')),
(tr('Что вызывает смену дня и ночи?','Күн менен түндүн алмашуусуна эмне себеп?','What causes day and night?'),['Вращение Земли / Earth rotation','Фазы Луны / Moon phases','Приливы / Tides','Ветер / Wind'],0,tr('Земля вращается вокруг своей оси.','Жер өз огунун айланасында айланат.','Earth rotates about its axis.'))]
for topic,items in [('chemistry',chem),('geography',geo)]:
    for i,(text,options,answer,explanation) in enumerate(items):science(topic,text,options,answer,explanation,i>=6)

ALL_QUESTIONS=QUESTIONS+SCIENCE
