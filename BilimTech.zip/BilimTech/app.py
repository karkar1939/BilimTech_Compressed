"""BilimTech demo version 0.3 — offline learning workspace."""
import csv
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from content import LANGS
from catalog import SUBJECTS,subject_for
from education import Platform,TeacherBank,AppError,VERSION
from labels import L
from ui import theme,Button,ScrollPage,Card,Answer,Progress,BG,WHITE,INK,MUTED,BLUE
from editor import BankEditor
from additions import photo,rename,choose_file

class App(tk.Tk):
    def __init__(self,path=None):
        super().__init__(); self.title('BilimTech — '+VERSION);self.geometry('1180x880');self.minsize(950,700)
        self.service=Platform(path);self.lang='ru';self.token=None;self.user=None;self.exam_active=False;self.render=None
        with self.service.connect() as db:
            for lang,name in db.execute('SELECT lang,name FROM section_name'):SUBJECTS['other'][lang]=name
        self.language=tk.StringVar(value='Русский');theme(self)
        header=ttk.Frame(self,padding=(28,18),style='Surface.TFrame');header.pack(fill='x')
        brand=ttk.Frame(header,style='Surface.TFrame');brand.pack(side='left')
        ttk.Label(brand,text='BilimTech',style='Brand.TLabel').pack(anchor='w')
        ttk.Label(brand,text=VERSION,style='Surface.TLabel').pack(anchor='w')
        self.header_actions=ttk.Frame(header,style='Surface.TFrame');self.header_actions.pack(side='right')
        self.logout_button=None; self.session_label=None
        combo=ttk.Combobox(self.header_actions,textvariable=self.language,values=list(LANGS),state='readonly',width=12)
        combo.pack(side='right',padx=10);combo.bind('<<ComboboxSelected>>',self.translate)
        self.nav=ttk.Frame(self,padding=(24,0),style='Surface.TFrame');self.nav.pack(fill='x')
        self.area=ttk.Frame(self,padding=(20,12,20,18),style='Surface.TFrame');self.area.pack(fill='both',expand=True)
        self.protocol('WM_DELETE_WINDOW',self.close);self.login_page()
    def t(self,key):return L.get(key,L['invalid'])[self.lang]
    def translated(self,obj):return obj.get(self.lang,obj.get('ru','')) if isinstance(obj,dict) else str(obj)
    def error(self,exc):
        text=self.t(str(exc)) if isinstance(exc,AppError) else str(exc)
        messagebox.showerror(self.t('error'),text,parent=self)
    def run(self,fn):
        try:return fn()
        except (ValueError,OSError,tk.TclError) as exc:self.error(exc)
        except Exception as exc:self.error(exc)
    def translate(self,event=None):
        self.lang=LANGS[self.language.get()];self.build_nav()
        if self.render:self.render()
    def page(self,title,subtitle='',render=None):
        self.render=render
        for w in self.area.winfo_children():w.destroy()
        self.scroller=ScrollPage(self.area);self.scroller.pack(fill='both',expand=True);self.body=self.scroller.content
        ttk.Label(self.body,text=title,style='Title.TLabel',wraplength=1000).pack(anchor='w',pady=(0,10))
        if subtitle:ttk.Label(self.body,text=subtitle,style='Muted.TLabel',wraplength=1000).pack(anchor='w',pady=(0,20))
    def finish(self):self.scroller.activate()
    def field(self,parent,label,var,password=False):
        ttk.Label(parent,text=label).pack(anchor='w',pady=(10,5))
        entry=ttk.Entry(parent,textvariable=var,show='•' if password else '',width=42);entry.pack(fill='x');return entry
    def section(self,title):
        frame=ttk.Frame(self.body,padding=(16,14));frame.pack(fill='x',pady=8)
        ttk.Label(frame,text=title,style='Heading.TLabel',wraplength=960).pack(anchor='w',pady=(0,10));return frame
    def button(self,parent,key,command,secondary=False,**pack):
        b=Button(parent,text=self.t(key),command=lambda:self.run(command),variant='secondary' if secondary else 'primary')
        b.pack(**(pack or {'anchor':'w','pady':8}));return b
    def build_nav(self):
        for w in self.nav.winfo_children():w.destroy()
        if self.logout_button:self.logout_button.destroy();self.logout_button=None
        if self.session_label:self.session_label.destroy();self.session_label=None
        if not self.token:return
        self.user=self.service.require(self.token)
        self.session_label=ttk.Label(self.header_actions,text=self.user['name']+' • '+self.t(self.user['role']),style='Surface.TLabel',wraplength=260);self.session_label.pack(side='left',padx=10)
        self.logout_button=Button(self.header_actions,text=self.t('logout'),command=lambda:self.run(self.logout),variant='secondary');self.logout_button.pack(side='left')
        items=[('subjects',self.home),('profile',lambda:self.profile())]
        if self.user['role']=='teacher':items=[('subjects',self.home),('students',self.dashboard),('create_exam',self.exam_creator),('bank',self.open_bank),('create_school',lambda:self.registration(create=True)),('profile',lambda:self.profile())]
        for i,(key,cmd) in enumerate(items):
            Button(self.nav,text=self.t(key),command=lambda f=cmd:self.run(lambda:self.navigate(f)),variant='secondary').grid(row=i//3,column=i%3,sticky='w',padx=(0,8),pady=4)
    def navigate(self,fn):
        if self.exam_active:
            if not messagebox.askyesno('BilimTech',self.t('cancel_exam'),parent=self):return
            self.service.cancel_exam(self.token,self.ticket);self.exam_active=False
        fn()
    def close(self):
        if self.exam_active and not messagebox.askyesno('BilimTech',self.t('cancel_exam'),parent=self):return
        if self.token:self.service.logout(self.token)
        self.destroy()
    def logout(self):
        def action():
            self.service.logout(self.token);self.token=None;self.user=None;self.build_nav();self.login_page()
        self.navigate(action)
    def authenticated(self,token):
        self.token=token;self.user=self.service.require(token)
        self.store=TeacherBank(self.service,token) if self.user['role']=='teacher' else None
        self.topics=self.service.legacy.topics();self.build_nav();self.home()
    def login_page(self):
        self.page(self.t('welcome'),self.t('local_note'),self.login_page)
        form=self.section(self.t('login'))
        role=tk.StringVar(value='student');user=tk.StringVar();password=tk.StringVar()
        rolebar=ttk.Frame(form);rolebar.pack(anchor='w',pady=10)
        for key in ('student','teacher'):ttk.Radiobutton(rolebar,text=self.t(key),variable=role,value=key).pack(side='left',padx=(0,20))
        entry=self.field(form,self.t('username'),user);self.field(form,self.t('password'),password,True)
        def login():self.authenticated(self.service.login(user.get(),password.get(),role.get()))
        self.button(form,'login',login)
        self.button(form,'register',self.registration,True)
        if not self.service.has_teacher():self.button(form,'first_teacher',lambda:self.registration(teacher=True),True)
        entry.focus_set();self.finish()
    def registration(self,teacher=False,create=False):
        if create:self.service.require(self.token,'teacher')
        self.page(self.t('create_teacher' if teacher and create else 'first_teacher' if teacher else 'create_school' if create else 'register'),self.t('setup_note' if teacher else 'study_note'),lambda:self.registration(teacher,create))
        vars={k:tk.StringVar() for k in ('username','name','password','confirm','school','classroom')}
        form=self.section(self.t('teacher' if teacher else 'student'))
        for k in ('name','username','password','confirm'):self.field(form,self.t(k),vars[k],k in ('password','confirm'))
        kind=tk.StringVar(value=self.t('study' if create else 'personal'))
        ttk.Label(form,text=self.t('kind')).pack(anchor='w',pady=(12,4))
        if create:ttk.Label(form,text=self.t('study')).pack(anchor='w')
        else:ttk.Combobox(form,textvariable=kind,values=[self.t('personal'),self.t('study')],state='readonly').pack(anchor='w')
        for k in ('school','classroom'):self.field(form,self.t(k),vars[k])
        if create:vars['school'].set(self.user['school'])
        def save():
            if vars['password'].get()!=vars['confirm'].get():raise AppError('password_mismatch')
            username=vars['username'].get();password=vars['password'].get()
            self.service.register(username,password,vars['name'].get(),kind='study' if create or kind.get()==self.t('study') else 'personal',school=vars['school'].get(),classroom=vars['classroom'].get(),role='teacher' if teacher else 'student',teacher_token=self.token if create else None)
            if create:messagebox.showinfo('BilimTech',self.t('saved'),parent=self);self.dashboard()
            else:self.authenticated(self.service.login(username,password,'teacher' if teacher else 'student'))
        self.button(form,'save' if create else 'register',save)
        self.button(form,'back',self.dashboard if create else self.login_page,True);self.finish()
    def home(self):
        self.service.require(self.token)
        self.page(self.t('subjects'),self.t('catalog_hint'),self.home)
        exams=self.service.exams(self.token)
        grid=ttk.Frame(self.body,style='Surface.TFrame');grid.pack(fill='x')
        for col in range(2):grid.columnconfigure(col,weight=1,uniform='subject')
        n=0
        for key,labels in SUBJECTS.items():
            items=[e for e in exams if e['subject']==key]
            if key=='other' and not items and self.user['role']!='teacher':continue
            card=Card(grid,height=240 if key=='other' else 190);card.grid(row=n//2,column=n%2,sticky='nsew',padx=6,pady=7);frame=card.content
            ttk.Label(frame,text=labels[self.lang],style='Heading.TLabel',wraplength=400).pack(anchor='w')
            ttk.Label(frame,text=f'{self.t("exams")}: {len(items)}',style='Muted.TLabel').pack(anchor='w',pady=10)
            self.button(frame,'open',lambda subject=key:self.subject_page(subject),True);n+=1
            if key=='other' and self.user['role']=='teacher':self.button(frame,'rename',lambda:rename(self),True)
        self.finish()
    def subject_page(self,subject):
        self.page(SUBJECTS[subject][self.lang],self.t('exams'),lambda:self.subject_page(subject))
        self.button(self.body,'back',self.home,True)
        exams=[e for e in self.service.exams(self.token) if e['subject']==subject]
        if not exams:ttk.Label(self.body,text=self.t('empty')).pack(anchor='w',pady=20)
        for e in exams:
            f=self.section(self.translated(e['title']))
            ttk.Label(f,text=f'{self.t("questions")}: {e["count"]}  •  {self.t("published" if e["published"] else "draft")}',style='Muted.TLabel').pack(anchor='w')
            ttk.Label(f,text=self.translated(e['description']),wraplength=950).pack(anchor='w',pady=8)
            self.button(f,'open',lambda eid=e['id']:self.exam_description(eid),True)
        self.finish()
    def exam_description(self,exam_id):
        exam=self.service.exam(self.token,exam_id)
        self.page(self.translated(exam['title']),SUBJECTS[exam['subject']][self.lang],lambda:self.exam_description(exam_id))
        f=self.section(self.t('description'));ttk.Label(f,text=self.translated(exam['description']),wraplength=980).pack(anchor='w')
        ttk.Label(f,text=f'{self.t("questions")}: {exam["count"]}',style='Muted.TLabel').pack(anchor='w',pady=15)
        ttk.Label(f,text=self.t('exam_hint'),wraplength=980).pack(anchor='w',pady=10)
        if self.user['role']=='student':
            used=sum(row['exam_id']==exam_id for row in self.service.history(self.token))
            ttk.Label(f,text=f'{self.t("used")}: {used} / {exam["tries"] or "∞"}').pack(anchor='w')
            if not exam['tries'] or used<exam['tries']:self.button(f,'start',lambda:self.begin_exam(exam_id))
            else:ttk.Label(f,text=self.t('limit_hit')).pack(anchor='w')
        else:
            if exam['author_id']==self.user['id']:self.button(f,'edit_exam',lambda:self.exam_creator(exam_id))
            review=self.section(self.t('questions'))
            for i,q in enumerate(exam['questions']):ttk.Label(review,text=f'{i+1}. {self.translated(q["text"])}',wraplength=980).pack(anchor='w',pady=8)
        self.button(self.body,'back',lambda:self.subject_page(exam['subject']),True);self.finish()
    def begin_exam(self,exam_id):
        exam=self.service.exam(self.token,exam_id)
        self.ticket,self.exam_questions=self.service.start_exam(self.token,exam_id)
        self.active_exam=exam;self.answer_vars=[tk.IntVar(value=-1) for q in self.exam_questions];self.exam_active=True
        self.exam_page()
    def exam_page(self):
        self.page(self.translated(self.active_exam['title']),self.t('exam_hint'),self.exam_page)
        self.question_frames=[]
        for i,(q,var) in enumerate(zip(self.exam_questions,self.answer_vars)):
            frame=self.section(f'{i+1}. {self.translated(q["text"])}');self.question_frames.append(frame)
            for j,option in enumerate(q['options']):Answer(frame,text=option,variable=var,value=j).pack(fill='x',pady=4)
        summary=self.section(f'{self.t("questions")}: {len(self.exam_questions)}')
        self.button(summary,'submit',self.submit_exam)
        self.button(summary,'back',lambda:self.navigate(lambda:self.exam_description(self.active_exam['id'])),True)
        self.finish()
    def submit_exam(self):
        answers=[v.get() for v in self.answer_vars]
        if -1 in answers:
            i=answers.index(-1);frame=self.question_frames[i]
            for child in frame.winfo_children():
                if isinstance(child,ttk.Label):child.configure(foreground='#a34335')
            self.update_idletasks();y=frame.winfo_y();height=self.body.winfo_height()
            self.scroller.canvas.yview_moveto(max(0,(y-20)/max(height,1)))
            messagebox.showwarning('BilimTech',self.t('answer_all'),parent=self);return
        sid=self.service.submit(self.token,self.ticket,answers);self.exam_active=False;self.result_page(sid)
    def result_page(self,sid):
        result=self.service.submission(self.token,sid)
        self.page(self.t('result'),self.translated(result['title']),lambda:self.result_page(sid))
        f=self.section(f'{result["correct"]} / {result["total"]}  •  {result["percent"]}%')
        Progress(f,value=result['percent']).pack(fill='x',pady=12)
        ttk.Label(f,text=self.t('saved')+' • '+result['created'].replace('T',' '),style='Muted.TLabel').pack(anchor='w')
        topics={}
        for item in result['payload']:
            q=item['question'];topics.setdefault(q['topic'],[]).append(int(item['selected']==q['answer']))
        labels=self.service.legacy.topics()
        for key,values in topics.items():
            percent=round(100*sum(values)/len(values),1)
            label=labels.get(key,{'ru':key}).get(self.lang,key)
            ttk.Label(f,text=f'{label}: {percent}%'+('  •  <70%' if percent<70 else '')).pack(anchor='w',pady=5)
        if self.user['role']=='student':
            practice_exams=self.service.exams(self.token)
            weak={key for key,values in topics.items() if sum(values)/len(values)<0.7}
            for exam in practice_exams:
                if exam['seed_key'] and exam['seed_key'].endswith('_practice') and exam['seed_key'][:-9] in weak:
                    Button(f,text=self.translated(exam['title']),command=lambda eid=exam['id']:self.run(lambda:self.exam_description(eid)),variant='secondary').pack(anchor='w',pady=6)
        self.button(f,'subjects',self.home,True)
        for i,item in enumerate(result['payload']):
            q=item['question'];answer=item['selected'];correct=q['answer']==answer
            f=self.section(f'{i+1}. {self.translated(q["text"])}')
            ttk.Label(f,text=self.t('correct' if correct else 'incorrect'),foreground=BLUE if correct else '#a34335').pack(anchor='w')
            ttk.Label(f,text=self.t('your_answer')+': '+q['options'][answer],wraplength=960).pack(anchor='w',pady=4)
            if not correct:ttk.Label(f,text=self.t('correct_answer')+': '+q['options'][q['answer']],wraplength=960).pack(anchor='w',pady=4)
            ttk.Label(f,text=self.translated(q['explanation']),wraplength=960,style='Muted.TLabel').pack(anchor='w',pady=6)
        self.finish()
    def profile(self,student_id=None):
        person=self.service.profile(self.token,student_id)
        history=self.service.history(self.token,person['id'])
        self.page(person['name'],self.t('teacher' if person['role']=='teacher' else 'student'),lambda:self.profile(student_id))
        f=self.section(self.t('profile') if student_id is None else self.t('view_profile'))
        photo(self,f,person['id'])
        for key,label in [('username','username'),('kind','kind'),('school','school'),('classroom','classroom'),('email','email'),('bio','bio'),('created','joined')]:
            value=self.t(person[key]) if key=='kind' else person[key]
            ttk.Label(f,text=self.t(label)+': '+(value or '—'),wraplength=950).pack(anchor='w',pady=5)
        if person['id']==self.user['id']:
            self.button(f,'edit_profile',self.edit_profile,True);self.button(f,'change_password',self.password_form,True)
            if self.user['role']=='teacher':self.button(f,'create_teacher',lambda:self.registration(teacher=True,create=True),True)
        if person['role']=='student':
            self.draw_chart(self.section(self.t('chart')),history)
            self.history_list(history)
        self.finish()
    def edit_profile(self):
        person=self.service.profile(self.token);self.page(self.t('edit_profile'),render=self.edit_profile)
        variables={key:tk.StringVar(value=person[key]) for key in ('name','school','classroom','email')}
        for key,var in variables.items():self.field(self.body,self.t(key),var)
        ttk.Label(self.body,text=self.t('bio')).pack(anchor='w',pady=(15,5))
        bio=tk.Text(self.body,height=4,wrap='word',font=('Roboto Condensed',11));bio.insert('1.0',person['bio']);bio.pack(fill='x')
        def save():self.service.update_profile(self.token,**{k:v.get() for k,v in variables.items()},bio=bio.get('1.0','end').strip());self.user=self.service.require(self.token);self.build_nav();self.profile()
        self.button(self.body,'save',save);self.button(self.body,'cancel',lambda:self.profile(),True);self.finish()
    def password_form(self):
        self.page(self.t('change_password'),render=self.password_form)
        old=tk.StringVar();new=tk.StringVar();confirm=tk.StringVar()
        for key,var in [('old_password',old),('new_password',new),('confirm',confirm)]:self.field(self.body,self.t(key),var,True)
        def save():
            if new.get()!=confirm.get():raise AppError('password_mismatch')
            self.service.change_password(self.token,old.get(),new.get());messagebox.showinfo('BilimTech',self.t('saved'),parent=self);self.profile()
        self.button(self.body,'save',save);self.button(self.body,'cancel',lambda:self.profile(),True);self.finish()
    def history_list(self,history):
        f=self.section(self.t('history'))
        if not history:ttk.Label(f,text=self.t('empty')).pack(anchor='w')
        for row in history:
            frame=ttk.Frame(f,padding=8);frame.pack(fill='x',pady=4)
            ttk.Label(frame,text=f'{self.translated(row["title"])}  •  {row["percent"]}%\n{row["created"].replace("T"," ")}',wraplength=900).pack(anchor='w')
            self.button(frame,'review',lambda sid=row['id']:self.result_page(sid),True)
    def draw_chart(self,parent,history):
        ttk.Label(parent,text=self.t('chart_hint'),style='Muted.TLabel',wraplength=960).pack(anchor='w',pady=(0,12))
        counts={}
        for row in history:counts[row['subject']]=counts.get(row['subject'],0)+1
        if counts:
            ttk.Label(parent,text=self.t('tries_chart'),style='Heading.TLabel').pack(anchor='w')
            for subject,count in counts.items():
                ttk.Label(parent,text=f'{SUBJECTS[subject][self.lang]} · {count}').pack(anchor='w')
                Progress(parent,maximum=max(counts.values()),value=count).pack(fill='x',pady=4)
        latest={}
        for row in history:
            key=(row['student_id'],row['exam_id'])
            if key not in latest:latest[key]=row
        groups={}
        for row in latest.values():groups.setdefault(row['subject'],[]).append(row['percent'])
        if not groups:ttk.Label(parent,text=self.t('empty')).pack(anchor='w');return
        labels=[SUBJECTS[k][self.lang] for k in groups];values=[sum(v)/len(v) for v in groups.values()]
        try:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            fig=Figure(figsize=(9,3.2),dpi=100,facecolor=WHITE);ax=fig.add_subplot(111)
            bars=ax.barh(labels,values,color='#5b86b6',height=0.45);ax.set_xlim(0,110);ax.set_ylim(-0.6,len(labels)-0.4);ax.invert_yaxis()
            ax.axvline(70,color=MUTED,linestyle='--',linewidth=1);ax.spines[['top','right','left']].set_visible(False)
            ax.spines['bottom'].set_color('#80aad3');ax.tick_params(colors=INK,labelsize=10)
            for bar,value in zip(bars,values):ax.text(value+1,bar.get_y()+bar.get_height()/2,f'{value:.1f}%',va='center',color=INK)
            fig.tight_layout();canvas=FigureCanvasTkAgg(fig,master=parent);canvas.draw();canvas.get_tk_widget().pack(fill='x')
        except ImportError:
            for label,value in zip(labels,values):
                ttk.Label(parent,text=f'{label}: {value:.1f}%').pack(anchor='w',pady=(8,3));Progress(parent,value=value).pack(fill='x')
    def dashboard(self):
        self.service.require(self.token,'teacher')
        self.page(self.t('students'),self.t('local_note'),self.dashboard)
        students=self.service.students(self.token);history=self.service.history(self.token)
        f=self.section(f'{self.t("student")}: {len(students)}  •  {self.t("attempts")}: {len(history)}')
        self.button(f,'create_school',lambda:self.registration(create=True),True);self.button(f,'export',self.export,True)
        self.draw_chart(self.section(self.t('chart')),history)
        search=tk.StringVar();self.field(self.body,self.t('filter'),search)
        roster=ttk.Frame(self.body);roster.pack(fill='x',pady=15)
        def refresh(*args):
            for w in roster.winfo_children():w.destroy()
            term=search.get().strip().casefold()
            visible=[s for s in students if term in (s['name']+' '+s['username']+' '+s['classroom']).casefold()]
            if not visible:ttk.Label(roster,text=self.t('empty')).pack(anchor='w')
            for person in visible:
                rows=[r for r in history if r['student_id']==person['id']]
                f=ttk.Frame(roster,padding=14);f.pack(fill='x',pady=4)
                ttk.Label(f,text=f'{person["name"]}  •  @{person["username"]}',font=('Roboto Condensed',12,'bold')).pack(anchor='w')
                ttk.Label(f,text=f'{person["school"] or "—"}  •  {self.t("classroom")}: {person["classroom"] or "—"}  •  {self.t("attempts")}: {len(rows)}',wraplength=960,style='Muted.TLabel').pack(anchor='w',pady=5)
                self.button(f,'view_profile',lambda uid=person['id']:self.profile(uid),True)
            self.finish()
        search.trace_add('write',refresh);refresh()
        self.button(self.body,'legacy',self.legacy_page,True);self.finish()
    def legacy_page(self):
        self.service.require(self.token,'teacher');self.page(self.t('legacy'),self.t('legacy_note'),self.legacy_page)
        rows=self.service.legacy.rows();groups={}
        for r in rows:groups.setdefault((r[0],r[1],r[2],r[3]),[]).append(r[8])
        if not groups:ttk.Label(self.body,text=self.t('empty')).pack(anchor='w')
        for key,values in groups.items():ttk.Label(self.body,text=f'{key[1]} • {key[2]} • {key[3]} • {100*sum(values)/len(values):.1f}%',wraplength=980).pack(anchor='w',pady=6)
        self.finish()
    def export(self):
        rows=self.service.history(self.token)
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',filetypes=[('CSV','*.csv')])
        if not path:return
        with open(path,'w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(['student','class','exam','subject','date','correct','total','percent'])
            for r in rows:writer.writerow([r['name'],r['classroom'],self.translated(r['title']),r['subject'],r['created'],r['correct'],r['total'],r['percent']])
        messagebox.showinfo('BilimTech',self.t('saved'),parent=self)
    def open_bank(self):
        self.service.require(self.token,'teacher');editor=BankEditor(self);editor.on_close=lambda:None
    def exam_creator(self,exam_id=None):
        self.service.require(self.token,'teacher')
        existing=self.service.exam(self.token,exam_id) if exam_id else None
        if existing and existing['author_id']!=self.user['id']:raise AppError('forbidden')
        self.page(self.t('edit_exam' if existing else 'create_exam'),self.t('select_questions'),lambda:self.exam_creator(exam_id))
        title=tk.StringVar(value=self.translated(existing['title']) if existing else '')
        self.field(self.body,self.t('exam_title'),title)
        ttk.Label(self.body,text=self.t('description')).pack(anchor='w',pady=(15,5))
        description=tk.Text(self.body,height=4,wrap='word',font=('Roboto Condensed',11));description.pack(fill='x')
        if existing:description.insert('1.0',self.translated(existing['description']))
        subject=tk.StringVar(value=SUBJECTS[existing['subject'] if existing else 'math'][self.lang])
        ttk.Label(self.body,text=self.t('subject')).pack(anchor='w',pady=(12,4))
        ttk.Combobox(self.body,values=[v[self.lang] for v in SUBJECTS.values()],textvariable=subject,state='readonly',width=35).pack(anchor='w')
        tries=tk.StringVar(value=str(existing['tries'] if existing else 0))
        self.field(self.body,self.t('limit'),tries)
        publish=tk.BooleanVar(value=bool(existing['published']) if existing else True)
        ttk.Checkbutton(self.body,text=self.t('publish'),variable=publish).pack(anchor='w',pady=10)
        actions=ttk.Frame(self.body);actions.pack(fill='x',pady=8)
        self.button(actions,'bank',self.open_bank,True,side='left',padx=(0,8))
        show_all=tk.BooleanVar(value=False)
        ttk.Checkbutton(self.body,text=self.t('show_all'),variable=show_all).pack(anchor='w')
        selected={q['id']:tk.BooleanVar(value=True) for q in existing['questions']} if existing else {}
        count=ttk.Label(self.body);count.pack(anchor='w',pady=8)
        listing=ttk.Frame(self.body);listing.pack(fill='x')
        def selected_count(*args):count.config(text=f'{self.t("selected")}: {sum(v.get() for v in selected.values())}')
        def refresh(*args):
            for w in listing.winfo_children():w.destroy()
            key=next(k for k,v in SUBJECTS.items() if v[self.lang]==subject.get())
            bank=self.service.bank(self.token)
            for q in bank:
                if not show_all.get() and subject_for(q['topic'])!=key:continue
                if q['id'] not in selected:
                    selected[q['id']]=tk.BooleanVar(value=False);selected[q['id']].trace_add('write',selected_count)
                text=self.translated(q['text'])
                tk.Checkbutton(listing,text=text,variable=selected[q['id']],wraplength=900,anchor='w',justify='left',background=WHITE,foreground=INK,activebackground='#c0e6fd',selectcolor=WHITE,font=('Roboto Condensed',11),padx=8,pady=8).pack(anchor='w',fill='x',pady=3)
            selected_count();self.finish()
        for var in selected.values():var.trace_add('write',selected_count)
        ttk.Style(self).configure('Exam.TCheckbutton',wraplength=950,padding=(8,8))
        self.button(actions,'refresh',refresh,True,side='left')
        def imported(ids):
            for qid in ids:
                selected[qid]=tk.BooleanVar(value=True)
                selected[qid].trace_add('write',selected_count)
            show_all.set(True)
        self.button(actions,'import_questions',lambda:choose_file(self,imported),True,side='left')
        subject.trace_add('write',refresh);show_all.trace_add('write',refresh)
        # The submission button stays at the bottom after the full question list.
        def save():
            key=next(k for k,v in SUBJECTS.items() if v[self.lang]==subject.get())
            titles=dict(existing['title']) if existing else {}
            descriptions=dict(existing['description']) if existing else {}
            for lang in ('ru','ky','en'):
                if not existing or lang==self.lang:titles[lang]=title.get().strip();descriptions[lang]=description.get('1.0','end').strip()
            eid=self.service.save_exam(self.token,key,titles,descriptions,[qid for qid,var in selected.items() if var.get()],publish.get(),exam_id,int(tries.get()))
            self.exam_description(eid)
        self.button(self.body,'save',save);self.button(self.body,'cancel',self.home,True)
        refresh()

if __name__=='__main__':App().mainloop()
