import sqlite3
import json
import random
import uuid
from datetime import datetime
from pathlib import Path
from content import QUESTIONS, TOPICS

class Store:
    def __init__(self, path=None):
        self.path=Path(path) if path else Path(__file__).resolve().parent/'bilimtech.sqlite3'
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS teacher_questions(id INTEGER PRIMARY KEY, payload TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)')
            db.execute('CREATE TABLE IF NOT EXISTS teacher_topics(id TEXT PRIMARY KEY, labels TEXT NOT NULL)')
            db.executescript('''CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY, student TEXT NOT NULL, classroom TEXT NOT NULL, created TEXT NOT NULL, mode TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS answers(attempt_id INTEGER REFERENCES attempts(id), question_id INTEGER NOT NULL, topic TEXT NOT NULL, selected INTEGER NOT NULL, correct INTEGER NOT NULL);''')
    def topics(self):
        topics = {key: dict(value) for key, value in TOPICS.items()}
        with self.connect() as db:
            for key, labels in db.execute('SELECT id, labels FROM teacher_topics'):
                topics[key] = json.loads(labels)
        return topics

    def add_topic(self, labels):
        if any(not str(labels.get(lang, '')).strip() for lang in ('ru','ky','en')):
            raise ValueError('Topic names required')
        key = 'teacher_' + uuid.uuid4().hex
        with self.connect() as db:
            db.execute('INSERT INTO teacher_topics VALUES(?,?)', (key,json.dumps(labels,ensure_ascii=False)))
        return key

    def bank(self, include_inactive=False):
        result = [dict(q, custom=False, active=True) for q in QUESTIONS]
        with self.connect() as db:
            for qid,payload,active in db.execute('SELECT id,payload,active FROM teacher_questions ORDER BY id'):
                if active or include_inactive:
                    result.append(dict(json.loads(payload), id=1000000+qid, custom=True, active=bool(active)))
        return result

    def put_question(self, payload, question_id=None):
        if payload.get('topic') not in self.topics(): raise ValueError('Unknown topic')
        for field in ('text','explanation'):
            if any(not str(payload.get(field,{}).get(lang,'')).strip() for lang in ('ru','ky','en')):
                raise ValueError('Question and explanation required')
        options=payload.get('options',[])
        if len(options)!=4 or any(not isinstance(o,str) or not o.strip() for o in options):
            raise ValueError('Four options required')
        if len({o.strip().casefold() for o in options})!=4: raise ValueError('Options must differ')
        if type(payload.get('answer')) is not int or payload['answer'] not in range(4): raise ValueError('Correct answer required')
        clean={k:payload[k] for k in ('topic','text','options','answer','explanation')}
        clean['options']=[option.strip() for option in options]
        clean['practice']=bool(payload.get('practice',False))
        with self.connect() as db:
            if question_id is None:
                qid=db.execute('INSERT INTO teacher_questions(payload) VALUES(?)',(json.dumps(clean,ensure_ascii=False),)).lastrowid
            else:
                qid=question_id-1000000
                changed=db.execute('UPDATE teacher_questions SET payload=? WHERE id=?',(json.dumps(clean,ensure_ascii=False),qid)).rowcount
                if not changed: raise ValueError('Unknown teacher question')
        return 1000000+qid

    def set_active(self, question_id, active):
        with self.connect() as db:
            if not db.execute('UPDATE teacher_questions SET active=? WHERE id=?',(int(active),question_id-1000000)).rowcount:
                raise ValueError('Unknown teacher question')

    def build_test(self, practice=False, topics=None, per_topic=5):
        selected=[]
        bank=self.bank()
        for topic in self.topics():
            if topics and topic not in topics: continue
            pool=[q for q in bank if q['practice']==practice and q['topic']==topic]
            selected.extend(random.sample(pool,min(per_topic,len(pool))))
        random.shuffle(selected)
        return selected

    def connect(self):
        db=sqlite3.connect(self.path)
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('CREATE TABLE IF NOT EXISTS answer_snapshots(attempt_id INTEGER, question_id INTEGER, payload TEXT NOT NULL)')
        return db
    def save(self,student,classroom,mode,responses):
        with self.connect() as db:
            aid=db.execute('INSERT INTO attempts(student,classroom,created,mode) VALUES(?,?,?,?)',(student,classroom,datetime.now().isoformat(timespec='seconds'),mode)).lastrowid
            for q,selected in responses:
                if selected not in range(len(q['options'])): raise ValueError('Invalid answer')
                db.execute('INSERT INTO answers VALUES(?,?,?,?,?)',(aid,q['id'],q['topic'],selected,int(selected==q['answer'])))
                db.execute('INSERT INTO answer_snapshots VALUES(?,?,?)',(aid,q['id'],json.dumps(q,ensure_ascii=False)))
        return aid
    def rows(self,classroom=None):
        with self.connect() as db:
            return db.execute('''SELECT a.id,a.student,a.classroom,a.created,a.mode,r.topic,r.question_id,r.selected,r.correct FROM attempts a JOIN answers r ON a.id=r.attempt_id '''+('WHERE a.classroom=? ' if classroom else '')+'ORDER BY a.id', (classroom,) if classroom else ()).fetchall()
    def demo(self):
        with self.connect() as db:
            if db.execute("SELECT 1 FROM attempts WHERE classroom='ДЕМО'").fetchone(): return
        for i in range(1,6):
            self.save(f'Demo {i}','ДЕМО','diagnostic',[(q,q['answer'] if (q['id']+i)%4 else (q['answer']+1)%4) for q in QUESTIONS if not q['practice']])

def scores(responses):
    result={}
    for q,answer in responses:
        hit,total=result.get(q['topic'],(0,0))
        result[q['topic']]=(hit+int(answer==q['answer']),total+1)
    return {topic:round(hit/total*100,1) for topic,(hit,total) in result.items()}
