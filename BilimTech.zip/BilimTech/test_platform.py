import unittest,tempfile,json,sqlite3
from pathlib import Path
from education import Platform,TeacherBank,AppError
from catalog import SUBJECTS,ALL_QUESTIONS,tr

class PlatformTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'db.sqlite3';self.p=Platform(self.path)
        self.p.register('teacher','Teacher123','Учитель',role='teacher')
        self.teacher=self.p.login('teacher','Teacher123','teacher')
        self.uid=self.p.register('student','Student123','Ученик',kind='study',school='Школа 1',classroom='6А')
        self.student=self.p.login('student','Student123','student')
    def tearDown(self):self.temp.cleanup()
    def test_accounts_roles_and_hashes(self):
        self.assertEqual(self.p.require(self.student)['role'],'student')
        with self.assertRaises(AppError):self.p.login('student','wrongpass','student')
        with self.assertRaises(AppError):self.p.login('student','Student123','teacher')
        with self.assertRaises(AppError):self.p.register('otherteacher','Teacher123','Other',role='teacher')
        self.p.register('teacher2','Teacher234','Second',role='teacher',teacher_token=self.teacher)
        for call in [lambda:self.p.students(self.student),lambda:TeacherBank(self.p,self.student).bank(),lambda:self.p.bank(self.student)]:
            with self.assertRaises(AppError):call()
        with self.p.connect() as db:
            row=db.execute('SELECT * FROM accounts WHERE id=?',(self.uid,)).fetchone()
            self.assertNotEqual(row['password_hash'],'Student123');self.assertEqual(len(row['salt']),32)
        with self.assertRaises(AppError):self.p.register('student','Student123','Duplicate')
        with self.assertRaises(AppError):self.p.register('no_school','Student123','A',kind='study')
        self.p.update_profile(self.student,'Новое имя','Школа 2','7Б','a@example.test','О себе')
        self.assertEqual(self.p.profile(self.student)['name'],'Новое имя')
        self.p.change_password(self.student,'Student123','Different123')
        with self.assertRaises(AppError):self.p.login('student','Student123','student')
        self.assertTrue(self.p.login('student','Different123','student'))
        self.p.logout(self.student)
        with self.assertRaises(AppError):self.p.require(self.student)
    def test_publication_snapshot_grading_and_ownership(self):
        qs=self.p.bank(self.teacher)[:3];ids=[q['id'] for q in qs]
        eid=self.p.save_exam(self.teacher,'math',tr('Тест','Тест','Test'),tr('Описание','Сүрөттөмө','Description'),ids,False)
        self.assertNotIn(eid,[e['id'] for e in self.p.exams(self.student)])
        with self.assertRaises(AppError):self.p.start_exam(self.student,eid)
        with self.assertRaises(AppError):self.p.save_exam(self.student,'math',tr('A','A','A'),tr('B','B','B'),ids,True)
        self.p.save_exam(self.teacher,'math',tr('Тест','Тест','Test'),tr('D','D','D'),ids,True,eid)
        exam=self.p.exam(self.student,eid)
        self.assertNotIn('answer',exam['questions'][0]);self.assertNotIn('explanation',exam['questions'][0])
        ticket,questions=self.p.start_exam(self.student,eid)
        with self.assertRaises(AppError):self.p.submit(self.student,ticket,[-1]*3)
        # Editing an exam after it starts must not change the attempt being graded.
        self.p.save_exam(self.teacher,'math',tr('Новый','Жаңы','New'),tr('D','D','D'),[ids[0]],True,eid)
        sid=self.p.submit(self.student,ticket,[q['answer'] for q in qs])
        record=self.p.submission(self.student,sid)
        self.assertEqual(record['correct'],3);self.assertEqual(record['total'],3)
        self.assertEqual(record['title']['ru'],'Тест')
        with self.assertRaises(AppError):self.p.submit(self.student,ticket,[q['answer'] for q in qs])
        self.p.register('other','Student123','Other');other=self.p.login('other','Student123','student')
        with self.assertRaises(AppError):self.p.profile(other,self.uid)
        with self.assertRaises(AppError):self.p.submission(other,sid)
        with self.assertRaises(AppError):self.p.history(other,self.uid)
        self.assertEqual(len(self.p.history(other)),0)
        self.assertEqual(len(self.p.history(self.teacher)),1)
        # Store and seed remain stable after restart.
        count=len(self.p.exams(self.teacher));reopened=Platform(self.path)
        t=reopened.login('student','Student123','student')
        self.assertEqual(len(reopened.history(t)),1)
        self.assertEqual(len(reopened.exams(t)),count)
    def test_content_and_legacy_preservation(self):
        subjects={e['subject'] for e in self.p.exams(self.student)}
        self.assertTrue({'math','geometry','physics','chemistry','geography'}<=subjects)
        for q in ALL_QUESTIONS:
            self.assertEqual(len(q['options']),4);self.assertEqual(len(set(q['options'])),4)
            for lang in ('ru','ky','en'):
                self.assertTrue(q['text'][lang]);self.assertTrue(q['explanation'][lang])
        self.p.legacy.save('Old name','6А','diagnostic',[(ALL_QUESTIONS[0],0)])
        self.assertEqual(len(Platform(self.path).legacy.rows()),1)
        self.assertEqual(len(self.p.history(self.student)),0)

if __name__=='__main__':unittest.main()
