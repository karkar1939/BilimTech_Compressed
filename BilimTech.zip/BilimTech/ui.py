"""Soft blue Tkinter theme, keyboard-accessible rounded controls, and scrolling cards."""
import tkinter as tk
from tkinter import ttk

BG='#c0e6fd'; WHITE='#ffffff'; INK='#000f22'; MUTED='#3f6593'
BLUE='#3f6593'; HOVER='#1b3554'; PALE='#c0e6fd'; BORDER='#80aad3'
FONT=('Roboto Condensed',11)

def rounded(canvas,x1,y1,x2,y2,r=18,**kwargs):
    if x2<=x1 or y2<=y1: return None
    r=min(r,(x2-x1)/2,(y2-y1)/2)
    return canvas.create_polygon(x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1,smooth=True,splinesteps=24,**kwargs)

def theme(root):
    from ctypes import CDLL, c_char_p, c_void_p
    from pathlib import Path
    try:
        fc=CDLL('libfontconfig.so.1')
        fc.FcConfigGetCurrent.restype=c_void_p
        fc.FcConfigAppFontAddFile.argtypes=[c_void_p,c_char_p]
        fc.FcConfigAppFontAddFile(fc.FcConfigGetCurrent(),bytes(Path(__file__).parent/'fonts'/'RobotoCondensed.ttf'))
    except OSError:pass
    root.configure(background=BG)
    root.option_add('*TCombobox*Listbox.background',WHITE)
    root.option_add('*TCombobox*Listbox.foreground',INK)
    root.option_add('*Text.background',WHITE); root.option_add('*Text.foreground',INK)
    root.option_add('*Text.highlightColor',BLUE); root.option_add('*Text.highlightBackground',BORDER)
    root.option_add('*Text.relief','flat'); root.option_add('*Text.highlightThickness',1)
    root.option_add('*Text.padX',12); root.option_add('*Text.padY',10)
    style=ttk.Style(root); style.theme_use('clam')
    style.configure('.',font=FONT,background=WHITE,foreground=INK)
    style.configure('TFrame',background=WHITE)
    style.configure('Surface.TFrame',background=BG)
    style.configure('TLabel',background=WHITE,foreground=INK)
    style.configure('Muted.TLabel',foreground=MUTED)
    style.configure('Title.TLabel',font=('Roboto Condensed',25,'bold'),foreground=INK)
    style.configure('Heading.TLabel',font=('Roboto Condensed',17,'bold'),foreground=INK)
    style.configure('Brand.TLabel',background=BG,foreground=BLUE,font=('Roboto Condensed',23,'bold'))
    style.configure('Surface.TLabel',background=BG,foreground=MUTED)
    style.configure('TNotebook',background=BG,bordercolor=BG,lightcolor=BG,darkcolor=BG,borderwidth=0,tabmargins=(0,0,0,14))
    style.layout('TNotebook.Tab',[('Notebook.padding',{'sticky':'nswe','children':[('Notebook.label',{'sticky':'nswe'})]})])
    style.configure('TNotebook.Tab',padding=(24,12),background=BG,foreground=MUTED,borderwidth=0)
    style.map('TNotebook.Tab',background=[('selected',PALE)],foreground=[('selected',BLUE)])
    for name in ('TEntry','TCombobox','TSpinbox'):
        style.configure(name,fieldbackground=WHITE,foreground=INK,bordercolor=BORDER,lightcolor=BORDER,darkcolor=BORDER,arrowsize=15,padding=9)
        style.map(name,bordercolor=[('focus',BLUE)],fieldbackground=[('readonly',WHITE)],selectbackground=[('!disabled',BLUE)],selectforeground=[('!disabled',WHITE)])
    style.configure('Horizontal.TProgressbar',background='#5b86b6',troughcolor=BG,borderwidth=0,thickness=8)
    style.configure('Treeview',background=WHITE,fieldbackground=WHITE,foreground=INK,rowheight=38,borderwidth=0)
    style.configure('Treeview.Heading',background=PALE,foreground=INK,padding=(10,12),font=('Roboto Condensed',10,'bold'),relief='flat')
    style.map('Treeview',background=[('selected',PALE)],foreground=[('selected',INK)])
    style.configure('TRadiobutton',background=WHITE,foreground=INK,padding=5)
    style.configure('Vertical.TScrollbar',background=PALE,troughcolor=BG,borderwidth=0,arrowsize=12)

class Button(tk.Canvas):
    """Canvas-backed button: rounded edges, hover, focus and keyboard activation."""
    def __init__(self,master,text='',command=None,variant='primary',**kwargs):
        from tkinter.font import Font
        font=Font(master,font=('Roboto Condensed',10,'bold'))
        self.command=command; self.text=text; self.variant=variant; self.hover=False; self.focused=False
        bg=master.cget('background') if 'background' in master.keys() else WHITE
        width=max(105,font.measure(text)+36)
        super().__init__(master,width=width,height=44,background=bg,highlightthickness=0,takefocus=True,cursor='hand2',**kwargs)
        self.font=font
        self.bind('<Configure>',self.draw); self.bind('<Enter>',lambda e:self.over(True)); self.bind('<Leave>',lambda e:self.over(False))
        self.bind('<Button-1>',lambda e:self.focus_set()); self.bind('<ButtonRelease-1>',self.click)
        self.bind('<Return>',lambda e:self.invoke()); self.bind('<space>',lambda e:self.invoke())
        self.bind('<FocusIn>',lambda e:self.focus_change(True)); self.bind('<FocusOut>',lambda e:self.focus_change(False))
    def over(self,value):
        self.hover=value
        if getattr(self,'timer',None):self.after_cancel(self.timer)
        def step():
            target=1 if self.hover else 0
            level=getattr(self,'level',0)
            self.level=round(level+max(-0.16,min(0.16,target-level)),2)
            self.draw()
            self.timer=self.after(16,step) if self.level!=target else None
        step()
    def focus_change(self,value): self.focused=value; self.draw()
    def draw(self,event=None):
        self.delete('all'); w=self.winfo_width(); h=self.winfo_height()
        fill=(HOVER if self.hover else BLUE) if self.variant=='primary' else (PALE if self.hover else '#f1f7fc')
        start,end=(BLUE,HOVER) if self.variant=='primary' else ('#f1f7fc',PALE)
        level=getattr(self,'level',0)
        fill='#'+''.join(f'{round(int(start[i:i+2],16)*(1-level)+int(end[i:i+2],16)*level):02x}' for i in (1,3,5))
        rounded(self,2,2,w-2,h-2,22,fill=fill,outline=BLUE if self.focused else fill,width=2)
        if self.focused: rounded(self,5,5,w-5,h-5,12,fill='',outline=WHITE if self.variant=='primary' else BLUE,dash=(3,2))
        self.create_text(w/2,h/2,text=self.text,font=self.font,fill=WHITE if self.variant=='primary' else BLUE)
    def invoke(self):
        if self.command: return self.command()
    def click(self,event):
        if 0<=event.x<=self.winfo_width() and 0<=event.y<=self.winfo_height(): self.invoke()

class Card(tk.Canvas):
    def __init__(self,master,**kwargs):
        super().__init__(master,background=BG,highlightthickness=0,**kwargs)
        self.content=ttk.Frame(self,padding=14)
        self.window=self.create_window(20,20,window=self.content,anchor='nw')
        self.bind('<Configure>',self.resize)
    def resize(self,event):
        self.delete('card')
        rounded(self,2,4,event.width-2,event.height-2,24,fill=BORDER,outline='',tags='card')
        rounded(self,2,1,event.width-2,event.height-5,24,fill=WHITE,outline='',tags='card')
        self.tag_lower('card'); self.itemconfigure(self.window,width=max(1,event.width-40),height=max(1,event.height-40))

class ScrollPage(ttk.Frame):
    def __init__(self,master):
        super().__init__(master,style='Surface.TFrame')
        self.canvas=tk.Canvas(self,background=BG,highlightthickness=0)
        scrollbar=ttk.Scrollbar(self,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side='left',fill='both',expand=True); scrollbar.pack(side='right',fill='y')
        self.content=ttk.Frame(self.canvas,padding=24)
        self.window=self.canvas.create_window(8,8,window=self.content,anchor='nw')
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=max(1,e.width-16)))
        self.content.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.bind_wheel(self.canvas); self.bind_wheel(self.content)
    def bind_wheel(self,widget):
        widget.bind('<Button-4>',lambda e:self.canvas.yview_scroll(-3,'units'),add='+')
        widget.bind('<Button-5>',lambda e:self.canvas.yview_scroll(3,'units'),add='+')
        widget.bind('<MouseWheel>',lambda e:self.canvas.yview_scroll(int(-e.delta/120),'units'),add='+')
    def activate(self):
        def visit(widget):
            for child in widget.winfo_children():
                if not isinstance(child,tk.Text): self.bind_wheel(child)
                visit(child)
        visit(self.content)

class Progress(tk.Canvas):
    def __init__(self,master,maximum=100,value=0):
        super().__init__(master,height=10,background=WHITE,highlightthickness=0)
        self.maximum=maximum; self.value=value; self.bind('<Configure>',self.draw)
    def draw(self,event=None):
        self.delete('all'); w=self.winfo_width()
        rounded(self,0,0,w,10,5,fill=BG,outline='')
        filled=w*max(0,min(1,self.value/self.maximum)) if self.maximum else 0
        if filled>1: rounded(self,0,0,filled,10,5,fill='#5b86b6',outline='')

class Answer(tk.Canvas):
    def __init__(self,master,text,variable,value,disabled=False):
        super().__init__(master,background=WHITE,highlightthickness=0,height=55)
        self.variable=variable; self.value=value; self.disabled=disabled
        self.radio=tk.Radiobutton(self,text=text,variable=variable,value=value,anchor='w',justify='left',wraplength=690,
            background='#f3f8fd',activebackground=PALE,foreground=INK,activeforeground=INK,selectcolor=WHITE,
            font=FONT,padx=8,pady=6,relief='flat',highlightthickness=0,command=self.paint,takefocus=not disabled)
        self.window=self.create_window(12,7,window=self.radio,anchor='nw')
        if disabled:self.radio.configure(state='disabled',disabledforeground=MUTED)
        self.trace=variable.trace_add('write',self.paint); self.bind('<Destroy>',self.cleanup)
        self.bind('<Configure>',self.resize)
        self.bind('<ButtonRelease-1>',lambda e:None if disabled else self.radio.invoke())
        self.radio.bind('<FocusIn>',self.paint,add='+'); self.radio.bind('<FocusOut>',self.paint,add='+')
        self.paint()
    def resize(self,event):
        self.radio.configure(wraplength=max(100,event.width-90))
        self.itemconfigure(self.window,width=max(1,event.width-24))
        height=self.radio.winfo_reqheight()+14
        if self.winfo_height()!=height:self.configure(height=height)
        self.paint()
    def paint(self,*args):
        selected=self.variable.get()==self.value
        fill=PALE if selected else '#f3f8fd'
        self.radio.configure(background=fill)
        self.delete('shape')
        focused=self.focus_get()==self.radio
        rounded(self,1,1,self.winfo_width()-1,self.winfo_height()-1,14,fill=fill,outline=BLUE if focused else ('#5b86b6' if selected else BORDER),tags='shape')
        self.tag_lower('shape')
    def cleanup(self,event):
        if event.widget==self:
            try:self.variable.trace_remove('write',self.trace)
            except tk.TclError:pass
