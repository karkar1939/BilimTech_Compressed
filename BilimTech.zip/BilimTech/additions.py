import csv
import json
import io
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, simpledialog
from catalog import SUBJECTS,tr
from labels import L
from ui import Button
from PIL import Image, ImageOps, ImageTk

L.update({
'import_questions':tr('Открыть файл вопросов','Суроолор файлын ачуу','Open question file'),
'import_selected':tr('Импортировать выбранные темы','Тандалган темаларды кошуу','Import selected topics'),
'limit':tr('Всего попыток (0 — без ограничения)','Аракет саны (0 — чексиз)','Attempt limit (0 = unlimited)'),
'used':tr('Использовано попыток','Колдонулган аракеттер','Attempts used'),
'limit_hit':tr('Все попытки использованы.','Аракеттер бүттү.','Attempt limit reached.'),
'rename':tr('Название раздела','Бөлүмдүн аталышы','Section name'),
'photo':tr('Выбрать фото профиля','Профиль сүрөтүн тандоо','Choose profile photo'),
'tries_chart':tr('Число сдач по предметам','Сабактар боюнча аракеттер','Attempts by subject')})

def init_tables(db):
    db.executescript('''CREATE TABLE IF NOT EXISTS section_name(lang TEXT PRIMARY KEY,name TEXT);
    CREATE TABLE IF NOT EXISTS avatar(uid INTEGER PRIMARY KEY,image BLOB);''')
    if 'tries' not in [r[1] for r in db.execute('PRAGMA table_info(exams)')]:
        db.execute('ALTER TABLE exams ADD COLUMN tries INTEGER NOT NULL DEFAULT 0')

def load_rows(path):
    with open(path,encoding='utf-8-sig',newline='') as stream:
        rows=list(csv.DictReader(stream)) if Path(path).suffix.lower()=='.csv' else json.load(stream)
    if not isinstance(rows,list) or not rows:raise ValueError('Expected a nonempty question list.')
    result=[]
    for i,row in enumerate(rows,1):
        try:
            topic=row['topic'].strip()
            text=row['question'].strip()
            explanation=row['explanation'].strip()
            options=[row[f'option{n}'].strip() for n in range(1,5)]
            answer=int(row['answer'])-1
            if not topic or not text or not explanation or not all(options) or len(set(options))!=4 or answer not in range(4):raise ValueError()
        except (TypeError,ValueError,KeyError,AttributeError) as exc:raise ValueError(f'Invalid question #{i}') from exc
        result.append((topic,dict(text=tr(text,text,text),options=options,answer=answer,explanation=tr(explanation,explanation,explanation),practice=False)))
    return result

def choose_file(app,done):
    app.service.require(app.token,'teacher')
    path=filedialog.askopenfilename(parent=app,filetypes=[('CSV / JSON','*.csv *.json')])
    if not path:return
    rows=load_rows(path)
    win=tk.Toplevel(app);win.title(app.t('import_questions'));win.transient(app);win.grab_set()
    from ui import ScrollPage
    win.geometry('480x420');page=ScrollPage(win);page.pack(fill='both',expand=True)
    selections={}
    for name in dict.fromkeys(n for n,q in rows):
        var=tk.BooleanVar(value=False);selections[name]=var
        ttk.Checkbutton(page.content,text=name,variable=var).pack(anchor='w')
    def save():
        app.service.require(app.token,'teacher')
        labels=app.service.legacy.topics()
        names={v.casefold():k for k,d in labels.items() for v in (*d.values(),k)}
        ids=[]
        with app.service.connect() as db:
            for name,q in rows:
                if not selections[name].get():continue
                if name.casefold() not in names:
                    key='teacher_'+uuid.uuid4().hex
                    db.execute('INSERT INTO teacher_topics VALUES(?,?)',(key,json.dumps(tr(name,name,name))))
                    names[name.casefold()]=key
                q['topic']=names[name.casefold()]
                ids.append(1000000+db.execute('INSERT INTO teacher_questions(payload) VALUES(?)',(json.dumps(q),)).lastrowid)
        if ids:win.destroy();done(ids)
    Button(page.content,text=app.t('import_selected'),command=lambda:app.run(save)).pack(pady=12)
    page.activate()

def rename(app):
    app.service.require(app.token,'teacher')
    value=simpledialog.askstring('BilimTech',app.t('rename'),initialvalue=SUBJECTS['other'][app.lang],parent=app)
    if value and value.strip():
        with app.service.connect() as db:db.execute('INSERT OR REPLACE INTO section_name VALUES(?,?)',(app.lang,value.strip()))
        SUBJECTS['other'][app.lang]=value.strip()
        app.home()

def photo(app,frame,uid):
    with app.service.connect() as db:row=db.execute('SELECT image FROM avatar WHERE uid=?',(uid,)).fetchone()
    if row:
        img=ImageTk.PhotoImage(Image.open(io.BytesIO(row[0])))
        view=ttk.Label(frame,image=img);view.image=img;view.pack(anchor='w')
    def choose():
        path=filedialog.askopenfilename(parent=app,filetypes=[('PNG / JPEG','*.png *.jpg *.jpeg')])
        if not path:return
        owner=app.service.require(app.token)['id']
        with Image.open(path) as image:
            image=ImageOps.fit(ImageOps.exif_transpose(image).convert('RGB'),(128,128))
            out=io.BytesIO();image.save(out,'PNG')
        with app.service.connect() as db:db.execute('INSERT OR REPLACE INTO avatar VALUES(?,?)',(owner,out.getvalue()))
        app.profile()
    if uid==app.user['id']:app.button(frame,'photo',choose,True)
