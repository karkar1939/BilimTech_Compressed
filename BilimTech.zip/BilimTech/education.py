"""Local demo accounts, role checks, exam publication and immutable submissions."""
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
from datetime import datetime
from core import Store
from catalog import ALL_QUESTIONS, SUBJECTS, subject_for, tr

VERSION='demo version 0.3'
class AppError(ValueError):pass

def now():return datetime.now().isoformat(timespec='seconds')
def public(row):return {k:row[k] for k in row.keys() if k not in ('salt','password_hash')}

class Platform:
    def __init__(self,path=None):
        self.legacy=Store(path); self.path=self.legacy.path; self.sessions={}; self.tickets={}
        with self.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS accounts(
              id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
              role TEXT NOT NULL CHECK(role IN ('student','teacher')),
              kind TEXT NOT NULL CHECK(kind IN ('personal','study')),
              school TEXT NOT NULL DEFAULT '', classroom TEXT NOT NULL DEFAULT '',
              email TEXT NOT NULL DEFAULT '', bio TEXT NOT NULL DEFAULT '',
              salt TEXT NOT NULL, password_hash TEXT NOT NULL, created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS exams(
              id INTEGER PRIMARY KEY, author_id INTEGER REFERENCES accounts(id), seed_key TEXT UNIQUE,
              subject TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL,
              questions TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS submissions(
              id INTEGER PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES accounts(id),
              exam_id INTEGER NOT NULL REFERENCES exams(id), title TEXT NOT NULL,
              subject TEXT NOT NULL, created TEXT NOT NULL, correct INTEGER NOT NULL,
              total INTEGER NOT NULL, payload TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS submission_student ON submissions(student_id,created);
            ''')
        from additions import init_tables
        with self.connect() as db:init_tables(db)
        self.seed()
    def connect(self):
        db=sqlite3.connect(self.path); db.row_factory=sqlite3.Row; db.execute('PRAGMA foreign_keys=ON'); return db
    def seed(self):
        groups={}
        for q in ALL_QUESTIONS:groups.setdefault((q['topic'],q['practice']),[]).append(q)
        topics=self.legacy.topics()
        with self.connect() as db:
            for (topic,practice),qs in groups.items():
                labels=topics[topic]
                title={l:labels[l]+(' • '+tr('Тренировка','Машыгуу','Practice')[l] if practice else ' • '+tr('Основы','Негиздер','Foundations')[l]) for l in labels}
                desc=tr('Проверь базовые знания. Ответь на все вопросы и нажми «Сдать экзамен» внизу. После сдачи появятся результат и объяснения.',
                        'Негизги билимиңди текшер. Бардык суроолорго жооп берип, төмөндөгү «Экзаменди тапшыруу» баскычын бас. Андан кийин жыйынтык жана түшүндүрмөлөр чыгат.',
                        'Check your foundations. Answer every question and select Submit exam at the bottom. Your score and explanations appear after submission.')
                # Compact fixed exam sets; remaining items stay available in the teacher bank.
                selected=qs[:min(10,len(qs))]
                db.execute('INSERT OR IGNORE INTO exams(author_id,seed_key,subject,title,description,questions,published,created) VALUES(NULL,?,?,?,?,?,1,?)',
                    (topic+('_practice' if practice else '_diagnostic'),subject_for(topic),json.dumps(title,ensure_ascii=False),json.dumps(desc,ensure_ascii=False),json.dumps(selected,ensure_ascii=False),now()))
    def has_teacher(self):
        with self.connect() as db:return bool(db.execute("SELECT 1 FROM accounts WHERE role='teacher'").fetchone())
    def register(self,username,password,name,kind='personal',school='',classroom='',role='student',teacher_token=None):
        username=username.strip().lower(); name=name.strip(); school=school.strip(); classroom=classroom.strip()
        if not re.fullmatch(r'[a-z0-9_.-]{3,40}',username):raise AppError('username_rule')
        if not 8<=len(password)<=256:raise AppError('password_rule')
        if not name or len(name)>100:raise AppError('name_rule')
        if role not in ('student','teacher') or kind not in ('personal','study'):raise AppError('invalid')
        if kind=='study' and not school:raise AppError('school_rule')
        if teacher_token:self.require(teacher_token,'teacher')
        salt=secrets.token_hex(16)
        hashed=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if role=='teacher' and not teacher_token and db.execute("SELECT 1 FROM accounts WHERE role='teacher'").fetchone():raise AppError('teacher_setup_closed')
            try:
                uid=db.execute('INSERT INTO accounts(username,name,role,kind,school,classroom,salt,password_hash,created) VALUES(?,?,?,?,?,?,?,?,?)',
                    (username,name,role,kind,school,classroom,salt,hashed,now())).lastrowid
            except sqlite3.IntegrityError:raise AppError('username_taken') from None
        return uid
    def login(self,username,password,role):
        with self.connect() as db:row=db.execute('SELECT * FROM accounts WHERE username=?',(username.strip().lower(),)).fetchone()
        # Same hash cost for unknown usernames; never return a password hash to the UI.
        salt=bytes.fromhex(row['salt']) if row else bytes(16)
        candidate=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,600000).hex()
        if not row or not hmac.compare_digest(row['password_hash'],candidate) or row['role']!=role:raise AppError('login_failed')
        token=secrets.token_urlsafe(32);self.sessions[token]=row['id'];return token
    def require(self,token,role=None):
        uid=self.sessions.get(token)
        with self.connect() as db:row=db.execute('SELECT * FROM accounts WHERE id=?',(uid,)).fetchone() if uid else None
        if not row or (role and row['role']!=role):raise AppError('forbidden')
        return public(row)
    def logout(self,token):
        self.sessions.pop(token,None)
        self.tickets={k:v for k,v in self.tickets.items() if v['token']!=token}
    def profile(self,token,student_id=None):
        user=self.require(token)
        uid=student_id if student_id is not None else user['id']
        if uid!=user['id'] and user['role']!='teacher':raise AppError('forbidden')
        with self.connect() as db:row=db.execute('SELECT * FROM accounts WHERE id=?',(uid,)).fetchone()
        if not row or (uid!=user['id'] and row['role']!='student'):raise AppError('forbidden')
        return public(row)
    def update_profile(self,token,name,school,classroom,email,bio):
        user=self.require(token)
        if not name.strip() or len(name)>100:raise AppError('name_rule')
        if user['kind']=='study' and not school.strip():raise AppError('school_rule')
        if any(len(x)>500 for x in (school,classroom,email)) or len(bio)>2000:raise AppError('invalid')
        with self.connect() as db:db.execute('UPDATE accounts SET name=?,school=?,classroom=?,email=?,bio=? WHERE id=?',
            (name.strip(),school.strip(),classroom.strip(),email.strip(),bio.strip(),user['id']))
    def change_password(self,token,old,new):
        user=self.require(token)
        if not 8<=len(new)<=256:raise AppError('password_rule')
        with self.connect() as db:
            row=db.execute('SELECT * FROM accounts WHERE id=?',(user['id'],)).fetchone()
            check=hashlib.pbkdf2_hmac('sha256',old.encode(),bytes.fromhex(row['salt']),600000).hex()
            if not hmac.compare_digest(check,row['password_hash']):raise AppError('login_failed')
            salt=secrets.token_hex(16); hashed=hashlib.pbkdf2_hmac('sha256',new.encode(),bytes.fromhex(salt),600000).hex()
            db.execute('UPDATE accounts SET salt=?,password_hash=? WHERE id=?',(salt,hashed,user['id']))
    def students(self,token):
        self.require(token,'teacher')
        with self.connect() as db:return [public(r) for r in db.execute("SELECT * FROM accounts WHERE role='student' ORDER BY name")]
    def bank(self,token):
        self.require(token,'teacher')
        return self.legacy.bank()+[dict(q,custom=False,active=True) for q in ALL_QUESTIONS if q['id']>=200000]
    def exams(self,token):
        user=self.require(token)
        with self.connect() as db:
            rows=db.execute('SELECT * FROM exams WHERE published=1 OR author_id=? ORDER BY id',(user['id'] if user['role']=='teacher' else -1,)).fetchall()
        return [self.decode_exam(r,questions=False) for r in rows]
    @staticmethod
    def decode_exam(row,questions=True):
        result=dict(row)
        for k in ('title','description','questions'):result[k]=json.loads(result[k])
        result['count']=len(result['questions'])
        if not questions:result.pop('questions')
        return result
    def exam(self,token,exam_id):
        user=self.require(token)
        with self.connect() as db:row=db.execute('SELECT * FROM exams WHERE id=?',(exam_id,)).fetchone()
        if not row or (not row['published'] and (user['role']!='teacher' or row['author_id']!=user['id'])):raise AppError('forbidden')
        result=self.decode_exam(row)
        if user['role']=='student':
            result['questions']=[{k:v for k,v in q.items() if k not in ('answer','explanation')} for q in result['questions']]
        return result
    def save_exam(self,token,subject,title,description,question_ids,published,exam_id=None,tries=None):
        user=self.require(token,'teacher')
        if tries is not None and (type(tries)!=int or not 0<=tries<=999):raise AppError('invalid')
        if subject not in SUBJECTS:raise AppError('invalid')
        if any(not title.get(l,'').strip() or not description.get(l,'').strip() for l in ('ru','ky','en')):raise AppError('exam_required')
        if not question_ids or len(question_ids)>100 or len(set(question_ids))!=len(question_ids):raise AppError('exam_questions')
        bank={q['id']:q for q in self.bank(token)}
        if any(q not in bank for q in question_ids):raise AppError('exam_questions')
        qs=[bank[q] for q in question_ids]
        with self.connect() as db:
            if exam_id is None:
                return db.execute('INSERT INTO exams(author_id,subject,title,description,questions,published,created,tries) VALUES(?,?,?,?,?,?,?,?)',
                    (user['id'],subject,json.dumps(title,ensure_ascii=False),json.dumps(description,ensure_ascii=False),json.dumps(qs,ensure_ascii=False),int(published),now(),tries or 0)).lastrowid
            row=db.execute('SELECT author_id FROM exams WHERE id=?',(exam_id,)).fetchone()
            if not row or row['author_id']!=user['id']:raise AppError('forbidden')
            db.execute('UPDATE exams SET subject=?,title=?,description=?,questions=?,published=? WHERE id=?',
                (subject,json.dumps(title,ensure_ascii=False),json.dumps(description,ensure_ascii=False),json.dumps(qs,ensure_ascii=False),int(published),exam_id))
            if tries is not None:db.execute('UPDATE exams SET tries=? WHERE id=?',(tries,exam_id))
            return exam_id
    def start_exam(self,token,exam_id):
        user=self.require(token,'student')
        with self.connect() as db:row=db.execute('SELECT * FROM exams WHERE id=? AND published=1',(exam_id,)).fetchone()
        if not row:raise AppError('forbidden')
        with self.connect() as db:self.check_limit(db,user['id'],exam_id)
        exam=self.decode_exam(row); ticket=secrets.token_urlsafe(24)
        self.tickets[ticket]={'token':token,'user':user['id'],'exam':exam}
        return ticket,[{k:v for k,v in q.items() if k not in ('answer','explanation')} for q in exam['questions']]
    def check_limit(self,db,uid,eid):
        limit=db.execute('SELECT tries FROM exams WHERE id=?',(eid,)).fetchone()[0]
        used=db.execute('SELECT COUNT(*) FROM submissions WHERE student_id=? AND exam_id=?',(uid,eid)).fetchone()[0]
        if limit and used>=limit:raise AppError('limit_hit')
    def cancel_exam(self,token,ticket):
        self.require(token)
        if ticket in self.tickets and self.tickets[ticket]['token']==token:self.tickets.pop(ticket)
    def submit(self,token,ticket,answers):
        user=self.require(token,'student'); pending=self.tickets.get(ticket)
        if not pending or pending['token']!=token:raise AppError('exam_expired')
        exam=pending['exam'];qs=exam['questions']
        if len(answers)!=len(qs) or any(type(a) is not int or a not in range(len(q['options'])) for q,a in zip(qs,answers)):raise AppError('answer_all')
        score=sum(q['answer']==a for q,a in zip(qs,answers))
        payload=[dict(question=q,selected=a) for q,a in zip(qs,answers)]
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self.check_limit(db,user['id'],exam['id'])
            sid=db.execute('INSERT INTO submissions(student_id,exam_id,title,subject,created,correct,total,payload) VALUES(?,?,?,?,?,?,?,?)',
                (user['id'],exam['id'],json.dumps(exam['title'],ensure_ascii=False),exam['subject'],now(),score,len(qs),json.dumps(payload,ensure_ascii=False))).lastrowid
        self.tickets.pop(ticket);return sid
    def history(self,token,student_id=None):
        user=self.require(token)
        if student_id is not None and student_id!=user['id'] and user['role']!='teacher':raise AppError('forbidden')
        if user['role']=='student':student_id=user['id']
        with self.connect() as db:
            rows=db.execute('SELECT s.*,a.name,a.classroom FROM submissions s JOIN accounts a ON a.id=s.student_id '+('WHERE s.student_id=? ' if student_id is not None else '')+'ORDER BY s.id DESC',(student_id,) if student_id is not None else ()).fetchall()
        result=[]
        for row in rows:
            item=dict(row);item['title']=json.loads(item['title']);item['payload']=json.loads(item['payload']);item['percent']=round(100*item['correct']/item['total'],1);result.append(item)
        return result
    def submission(self,token,sid):
        user=self.require(token)
        with self.connect() as db:row=db.execute('SELECT student_id FROM submissions WHERE id=?',(sid,)).fetchone()
        if not row:raise AppError('invalid')
        if user['role']=='student' and user['id']!=row['student_id']:raise AppError('forbidden')
        return next(r for r in self.history(token,row['student_id']) if r['id']==sid)

class TeacherBank:
    """Adapter for the existing question editor, guarded by an authenticated teacher session."""
    def __init__(self,platform,token):self.platform=platform;self.token=token
    def topics(self):self.platform.require(self.token,'teacher');return self.platform.legacy.topics()
    def bank(self,include_inactive=False):
        self.platform.require(self.token,'teacher')
        legacy=self.platform.legacy.bank(include_inactive)
        return legacy+[dict(q,custom=False,active=True) for q in ALL_QUESTIONS if q['id']>=200000]
    def add_topic(self,*args):self.platform.require(self.token,'teacher');return self.platform.legacy.add_topic(*args)
    def put_question(self,*args):self.platform.require(self.token,'teacher');return self.platform.legacy.put_question(*args)
    def set_active(self,*args):self.platform.require(self.token,'teacher');return self.platform.legacy.set_active(*args)
