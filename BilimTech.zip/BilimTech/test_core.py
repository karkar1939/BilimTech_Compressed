import tempfile
import unittest
from pathlib import Path
from core import Store, scores
from content import QUESTIONS, TEXT, TOPICS

class Tests(unittest.TestCase):
    def test_scoring_and_persistence(self):
        qs=[q for q in QUESTIONS if not q['practice']]
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'test.sqlite3')
            answers=[(q,q['answer']) for q in qs]
            self.assertEqual(set(scores(answers).values()),{100})
            store.save('Test','6А','diagnostic',answers)
            self.assertEqual(len(store.rows('6А')),len(qs))
            self.assertEqual(store.rows('7А'),[])
            store.demo(); count=len(store.rows()); store.demo()
            self.assertEqual(len(store.rows()),count)
            self.assertEqual(len(store.rows('ДЕМО')),5*len(qs))
    def test_content_and_gaps(self):
        for lang in ('ru','ky','en'):
            self.assertEqual(len(TEXT[lang]),35)
            for q in QUESTIONS:
                self.assertTrue(q['text'][lang]); self.assertTrue(q['explanation'][lang])
                self.assertIn(q['answer'],range(len(q['options'])))
                self.assertEqual(len(set(q['options'])),4)
        qs=[q for q in QUESTIONS if not q['practice']]
        answers=[(q,(q['answer']+1)%4 if q['topic']=='fractions' else q['answer']) for q in qs]
        self.assertEqual(scores(answers),{topic:0 if topic=='fractions' else 100 for topic in {q['topic'] for q in QUESTIONS}})
        for t in {q['topic'] for q in QUESTIONS}:
            self.assertGreaterEqual(sum(q['practice'] and q['topic']==t for q in QUESTIONS),13)

class TeacherBankTests(unittest.TestCase):
    def test_add_edit_disable_persist_and_snapshot(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'db.sqlite3'; store=Store(path)
            topic=store.add_topic({'ru':'Геометрия','ky':'Геометрия','en':'Geometry'})
            q={'topic':topic,'text':{l:'2 + 2 = ?' for l in TEXT},'explanation':{l:'2 + 2 = 4' for l in TEXT},'options':['1','2','3','4'],'answer':3,'practice':False}
            qid=store.put_question(q)
            loaded=Store(path)
            picked=loaded.build_test(False,[topic],5)
            self.assertEqual(len(picked),1); self.assertEqual(picked[0]['id'],qid)
            self.assertEqual(loaded.build_test(True,[topic],5),[])
            loaded.save('Teacher test','6А','diagnostic',[(picked[0],3)])
            q['text']['ru']='Edited question'; q['answer']=0
            loaded.put_question(q,qid)
            self.assertEqual(next(x for x in loaded.bank() if x['id']==qid)['answer'],0)
            self.assertEqual(loaded.rows('6А')[0][8],1)
            with loaded.connect() as db:
                old=json.loads(db.execute('SELECT payload FROM answer_snapshots').fetchone()[0])
                self.assertEqual(old['answer'],3); self.assertEqual(old['text']['ru'],'2 + 2 = ?')
            loaded.set_active(qid,False)
            self.assertEqual(loaded.build_test(False,[topic],5),[])
            self.assertFalse(next(x for x in loaded.bank(True) if x['id']==qid)['active'])
            loaded.set_active(qid,True)
            self.assertEqual(len(loaded.build_test(False,[topic],5)),1)
    def test_validation_and_sampling(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'db')
            q=dict(QUESTIONS[0]); q['options']=['1','1','2','3']
            with self.assertRaises(ValueError): store.put_question(q)
            with self.assertRaises(ValueError): store.add_topic({'ru':'', 'ky':'', 'en':''})
            sample=store.build_test(False,per_topic=5)
            self.assertEqual(len(sample),5*len({q['topic'] for q in QUESTIONS}))
            self.assertEqual(len({q['id'] for q in sample}),5*len({q['topic'] for q in QUESTIONS}))
            self.assertTrue(all(not q['practice'] for q in sample))
            self.assertEqual(len(store.build_test(True,['fractions'],5)),5)
            self.assertEqual(len(store.build_test(False,per_topic=20)),90)

if __name__=='__main__': unittest.main()
